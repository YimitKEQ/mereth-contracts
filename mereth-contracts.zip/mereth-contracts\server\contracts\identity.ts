// Who a character actually is.
//
// This exists because the obvious call is the wrong one. `mp.getActorName(formId)` returns
// the BASE RECORD's name, and every player character is built on the same base record, the
// vanilla player NPC_ at 0x7. That record is called "Prisoner", after the opening of the
// game. So a contract board built on getActorName cheerfully reports that Prisoner posted
// work for Prisoner and Prisoner took it.
//
// The name a player actually chose lives in the character's APPEARANCE, which is also what
// SkyMP renders above their head: the client does
//
//     refr.setDisplayName(model.appearance.name, true)
//
// on every appearance update. `appearance` is a readable server property, so the server can
// ask for the same string the nameplate shows. It is null until a character has been made.
//
// The stable identity is `profileId`, not the form id. Form ids are dynamic (0xff000000 and
// up) and are reassigned across sessions; profileId is what persists in the ChangeForm and
// what `getActorsByProfileId` looks up. Anything that must still mean the same person
// tomorrow should be keyed on it.

import type { MpApi } from "../mp";

/** Shown when a character has no appearance yet. Never a form id, never "Prisoner". */
export const UNNAMED = "An unnamed traveller";

/**
 * The vanilla base record name for the player. Seeing it means the appearance was missing
 * and getActorName fell through to the base, not that somebody is called this.
 */
const BASE_RECORD_NAME = "Prisoner";

interface Appearance {
  name?: unknown;
}

/** The name this character chose, the same string SkyMP puts above their head. */
export function characterName(mp: MpApi, formId: number): string {
  try {
    const appearance = mp.get(formId, "appearance") as Appearance | null;
    const chosen = appearance?.name;
    if (typeof chosen === "string" && chosen.trim() !== "") return chosen.trim();
  } catch {
    // An actor that has gone away has no name. Fall through rather than throwing into a
    // caller that is only trying to render a row.
  }

  try {
    const actorName = mp.getActorName(formId);
    // Anything but the base record name means a real name was set some other way, which is
    // worth keeping. The base record name means there is nothing here.
    if (typeof actorName === "string" && actorName.trim() !== "" && actorName !== BASE_RECORD_NAME) {
      return actorName.trim();
    }
  } catch {
    // Same reasoning as above.
  }

  return UNNAMED;
}

/**
 * The account behind the character, or null when there is none.
 *
 * A freshly placed actor reports -1, which is the server's way of saying "no account", so it
 * is normalised to null rather than passed on as a number that looks like an id.
 */
export function profileIdOf(mp: MpApi, formId: number): number | null {
  try {
    const raw = mp.get(formId, "profileId");
    const profileId = Number(raw);
    return Number.isInteger(profileId) && profileId >= 0 ? profileId : null;
  } catch {
    return null;
  }
}
