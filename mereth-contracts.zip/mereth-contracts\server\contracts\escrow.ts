// Moving coin and goods, the only part of the contract system that is not pure.
//
// This works on the server's `inventory` property rather than the Papyrus VM. That was not
// the first attempt: calling ObjectReference.AddItem through callPapyrusFunction fails,
// because the VM only resolves forms that are instantiated in the world state and an item
// like Gold001 is an ESPM base record. It throws "Form with id 0xf doesn't exist" when
// passed a form desc, and silently adds nothing when passed a numeric id. The live server
// caught that; a simulator never would have.
//
// The inventory property is also the better answer on the merits: it IS the server's
// authoritative model, it persists as a ChangeForm for free, and it needs no VM round trip.
//
// Two rules govern everything here:
//   1. Never create coin. Every septim paid out was first taken from somebody.
//   2. Take before you promise. If binding escrow fails, the contract is never created.

import type { MpApi } from "../mp";

/** Gold001, verified against the form codex built from the installed masters. */
export const GOLD_FORM_ID = 0x0000000f;

const INVENTORY = "inventory";

/**
 * One inventory stack. Beyond baseId and count, entries can carry extra data (enchantment,
 * temper, charge, custom name), and those fields are preserved untouched: two stacks of the
 * same baseId with different extra data are genuinely different items.
 */
export interface InventoryEntry {
  baseId: number;
  count: number;
  [extra: string]: unknown;
}

export interface Inventory {
  entries: InventoryEntry[];
}

export function readInventory(mp: MpApi, holder: number): Inventory {
  const raw = mp.get(holder, INVENTORY);
  if (typeof raw !== "object" || raw === null) return { entries: [] };
  const entries = (raw as { entries?: unknown }).entries;
  if (!Array.isArray(entries)) return { entries: [] };
  return {
    entries: entries.filter(
      (e): e is InventoryEntry =>
        typeof e === "object" &&
        e !== null &&
        typeof (e as InventoryEntry).baseId === "number" &&
        typeof (e as InventoryEntry).count === "number",
    ),
  };
}

function writeInventory(mp: MpApi, holder: number, inventory: Inventory): void {
  mp.set(holder, INVENTORY, inventory);
}

/** Total across every stack of this item, since extra data can split one item into several. */
export function countIn(inventory: Inventory, baseId: number): number {
  return inventory.entries.reduce((sum, e) => (e.baseId === baseId ? sum + e.count : sum), 0);
}

export function itemCount(mp: MpApi, holder: number, baseId: number): number {
  return countIn(readInventory(mp, holder), baseId);
}

export function coinHeldBy(mp: MpApi, holder: number): number {
  return itemCount(mp, holder, GOLD_FORM_ID);
}

/** Returns a NEW inventory with `count` more of the item. Never mutates its input. */
export function withAdded(inventory: Inventory, baseId: number, count: number): Inventory {
  if (count <= 0) return inventory;
  // Merge into the first plain stack. A stack carrying extra data is a distinct item and
  // must not absorb generic additions, or an enchanted sword would swallow a plain one.
  const at = inventory.entries.findIndex((e) => e.baseId === baseId && Object.keys(e).length === 2);
  if (at === -1) return { entries: [...inventory.entries, { baseId, count }] };
  return {
    entries: inventory.entries.map((e, i) => (i === at ? { ...e, count: e.count + count } : e)),
  };
}

/** Returns a NEW inventory with `count` fewer, or null when the holder does not have them. */
export function withRemoved(inventory: Inventory, baseId: number, count: number): Inventory | null {
  if (count <= 0) return inventory;
  if (countIn(inventory, baseId) < count) return null;

  let left = count;
  const entries: InventoryEntry[] = [];
  for (const entry of inventory.entries) {
    if (left === 0 || entry.baseId !== baseId) {
      entries.push(entry);
      continue;
    }
    const take = Math.min(left, entry.count);
    left -= take;
    const remaining = entry.count - take;
    if (remaining > 0) entries.push({ ...entry, count: remaining });
  }
  return { entries };
}

/** Removes coin and reports how much actually moved. Refuses rather than partially taking. */
export function takeCoin(mp: MpApi, holder: number, amount: number): number {
  return takeItem(mp, holder, GOLD_FORM_ID, amount);
}

export function takeItem(mp: MpApi, holder: number, baseId: number, amount: number): number {
  if (!Number.isInteger(amount) || amount < 0) throw new Error("amount must be a whole number");
  if (amount === 0) return 0;

  const before = readInventory(mp, holder);
  const after = withRemoved(before, baseId, amount);
  if (after === null) return 0;

  writeInventory(mp, holder, after);

  // Verify by recount rather than trusting the write. A partial take reported as success is
  // exactly how coin gets conjured out of nothing.
  const moved = countIn(before, baseId) - itemCount(mp, holder, baseId);
  if (moved !== amount) {
    writeInventory(mp, holder, before);
    throw new Error(`take was partial: wanted ${amount}, moved ${moved}`);
  }
  return amount;
}

export function giveCoin(mp: MpApi, holder: number, amount: number): void {
  giveItem(mp, holder, GOLD_FORM_ID, amount);
}

export function giveItem(mp: MpApi, holder: number, baseId: number, amount: number): void {
  if (!Number.isInteger(amount) || amount < 0) throw new Error("amount must be a whole number");
  if (amount === 0) return;
  writeInventory(mp, holder, withAdded(readInventory(mp, holder), baseId, amount));
}

export interface GoodsCheck {
  ok: boolean;
  held: number;
  needed: number;
}

/** Does the worker actually hold what the contract demands? The server counts, not the UI. */
export function checkGoods(mp: MpApi, worker: number, baseId: number, count: number): GoodsCheck {
  const held = itemCount(mp, worker, baseId);
  return { ok: held >= count, held, needed: count };
}

/**
 * Move goods from worker to client, reporting honestly whether it happened.
 *
 * Takes first and only credits the client once the take is confirmed, so a failure leaves
 * the goods with the worker rather than duplicating or destroying them.
 */
export function transferGoods(
  mp: MpApi,
  worker: number,
  client: number,
  baseId: number,
  count: number,
): boolean {
  let taken = 0;
  try {
    taken = takeItem(mp, worker, baseId, count);
  } catch {
    return false;
  }
  if (taken !== count) return false;

  try {
    giveItem(mp, client, baseId, count);
  } catch (error) {
    // Put them back. Losing a player's goods is far worse than a failed delivery.
    giveItem(mp, worker, baseId, count);
    throw error;
  }
  return true;
}
