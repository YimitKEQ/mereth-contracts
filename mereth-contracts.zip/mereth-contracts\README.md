# Contracts, for Mereth

Player to player work contracts for a SkyMP server. One player posts a job, another takes
it, the server holds the gold and keeps the receipts. Server side only. Players install
nothing.

Contracts bind to a character rather than an account, and each one belongs to the hold whose
board it was pinned at. Both are inside the tamper seal. See "Folding it into the missive
board" below for the one property you need to set.

Written by Kees (Yimmy) for Mereth Roleplay. MIT licensed, see LICENSE. Take it, change it,
ship it, no need to tell me.

Full writeup, a clickable board and the reasoning behind every decision:
https://yimitkeq.github.io/mereth-contracts/

## What is in here

    server/contracts/   the module, six files, nothing imported outside node and SkyMP types
    server/canonical.ts deterministic serialisation, used by the tamper seal
    server/mp.ts        the SkyMP server API typed, drop it if you already have your own
    tests/              the contract rules, run with vitest
    ui/contracts/       a standalone board, only if you do not want to draw it yourself

## Installing

1. Copy `server/contracts/` and `server/canonical.ts` next to your gamemode. If you already
   type the `mp` global yourself, delete `server/mp.ts` and point the imports at yours.

2. Four lines in your gamemode:

       import { makeDeps, registerContracts, sweepDelivered, sweepExpired } from "./contracts/service";
       import { makeWireState, pushViews, registerWire } from "./contracts/wire";

       const contracts = makeDeps(process.env["CONTRACT_SECRET"], console.log);
       const state = makeWireState();

       registerContracts(contracts);
       registerWire(contracts, state);

       setInterval(() => pushViews(contracts, state), 1000);
       setInterval(() => { sweepExpired(contracts); sweepDelivered(contracts); }, 3600000);

3. Two settings in `server-settings.json`:

       "enableGamemodeDataUpdatesBroadcast": true,
       "serverKey": { "private": "<pkcs8 pem>", "alias": "mereth" }

   Both are required and both fail silently when missing. The client simply never hears
   about the properties, with no error anywhere.

4. Show it. Your own UI already receives server data this way:

       window.addEventListener("mereth:contracts", (e) => setBoard(e.detail));

   Or drop `ui/contracts/index.html` into `Data/Platform/UI/mereth/` and write nothing.

## Folding it into the missive board

Built for this, not retrofitted to it.

**Contracts bind to the character, not the account.** `Party` carries `actorId`, which is the
actor form id and persists whether they are online or not. `profileId` is still readable in
`identity.ts` for moderation, but nothing binds to it: it is account wide, so two characters
belonging to one player would otherwise share a reputation and a debt history. `actorId` is
inside the seal, so a record whose party was swapped for another character fails verification.

**Each contract belongs to a hold.** The hold is whichever board it was pinned at, it is part
of the terms seal, and it cannot be changed afterwards without breaking the record. Set it on
the draft:

    { kind: "service", title: "...", reward: 450, hold: "Falkreath", ... }

**Tell the module where a player is standing** by writing one property when they use a board.
Contracts never guess this from coordinates: the board in Falkreath knows it is in Falkreath.

    mp.set(pcFormId, "mereth:hold", "Falkreath");

That is the only integration point. With it set, `view.board` is the work on that hold's board
plus anything posted without a hold, and `view.boards` is `[{ hold, open }]` for every other
hold with work, which is what a tab strip needs to show counts.

**Nothing disappears if you merge this before the boards are wired.** A contract with no hold
is visible everywhere, so behaviour only becomes local as holds start being set. There is no
migration step.

The scoping rule is exported on its own if you would rather call it directly:

    import { visibleOnBoard } from "./contracts/wire";
    const onThisBoard = visibleOnBoard(openContracts, "Falkreath");

`CONTRACT_SECRET` is the HMAC key for the tamper seal on contracts and debt notes. Any long
random string. Keep it out of source control. Changing it invalidates existing seals.

## Checking it before you trust it

The module verifies itself against your live server on boot, on your ESPM data and your
database. No fixtures, nothing to install. It posts real contracts, locks real gold,
defaults one on purpose, writes the debt note and checks the arithmetic:

    import { runSelfTest } from "./contracts/selftest";
    runSelfTest(contracts);

Anything other than `CONTRACTS OK` in the log means do not ship it.

The pure rules also test headless in milliseconds, if you have vitest:

    npx vitest run tests/

## The two things worth knowing before you read the code

**Gold is never minted.** Every septim paid out came off somebody first, and escrow is taken
before a contract exists, so a failure leaves no contract rather than one nobody can pay.

**A player never says who they are.** Actions carry an id and nothing else. Identity comes
off the connection, server side, every time.
