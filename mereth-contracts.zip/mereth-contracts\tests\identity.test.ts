// Naming, which was wrong in a way that only showed up on a live server.
//
// `mp.getActorName(formId)` returns the BASE RECORD's name, and every player character is
// built on the same base record: the vanilla player NPC_ at 0x7, called "Prisoner". So the
// contract board reported that Prisoner had posted work for Prisoner and Prisoner had taken
// it, which reads as a bug in the contract code and is not one.
//
// These lock in the real rule: the name a player chose lives in the character's appearance,
// which is the same string SkyMP puts above their head.

import { describe, expect, it } from "vitest";
import { UNNAMED, characterName, profileIdOf } from "../server/contracts/identity.ts";
import type { MpApi } from "../server/mp.ts";

/** Just enough of the server API to answer the two questions identity asks. */
function fakeMp(props: Record<string, unknown>, actorName = "Prisoner"): MpApi {
  return {
    get(_formId: number, propertyName: string) {
      if (!(propertyName in props)) throw new Error(`Property '${propertyName}' doesn't exist`);
      return props[propertyName];
    },
    getActorName() {
      return actorName;
    },
  } as unknown as MpApi;
}

describe("characterName", () => {
  it("uses the name from the appearance, which is what the nameplate shows", () => {
    const mp = fakeMp({ appearance: { name: "Aldric Vane" } });
    expect(characterName(mp, 0xff000001)).toBe("Aldric Vane");
  });

  it("never reports the base record name as a player's name", () => {
    // Appearance is null until a character has been made. getActorName would say "Prisoner".
    const mp = fakeMp({ appearance: null });
    expect(characterName(mp, 0xff000001)).toBe(UNNAMED);
  });

  it("still refuses the base record name when appearance is missing entirely", () => {
    const mp = fakeMp({});
    expect(characterName(mp, 0xff000001)).toBe(UNNAMED);
  });

  it("keeps a real name that arrived some other way", () => {
    const mp = fakeMp({}, "Ysolda");
    expect(characterName(mp, 0xff000001)).toBe("Ysolda");
  });

  it("trims, and treats a blank appearance name as no name at all", () => {
    expect(characterName(fakeMp({ appearance: { name: "  Brynjar  " } }), 1)).toBe("Brynjar");
    expect(characterName(fakeMp({ appearance: { name: "   " } }), 1)).toBe(UNNAMED);
  });

  it("survives an appearance that is not shaped the way we expect", () => {
    expect(characterName(fakeMp({ appearance: { name: 42 } }), 1)).toBe(UNNAMED);
    expect(characterName(fakeMp({ appearance: "not an object" }), 1)).toBe(UNNAMED);
  });

  it("survives an actor that has gone away", () => {
    const mp = {
      get() {
        throw new Error("Form with id 0xff000001 doesn't exist");
      },
      getActorName() {
        throw new Error("Form with id 0xff000001 doesn't exist");
      },
    } as unknown as MpApi;
    expect(characterName(mp, 0xff000001)).toBe(UNNAMED);
  });
});

describe("profileIdOf", () => {
  it("reports the account behind the character", () => {
    expect(profileIdOf(fakeMp({ profileId: 7 }), 1)).toBe(7);
  });

  it("treats the server's -1 as no account rather than as an id", () => {
    // A freshly placed actor, and anything else without a login, reports -1.
    expect(profileIdOf(fakeMp({ profileId: -1 }), 1)).toBeNull();
  });

  it("returns null rather than guessing when the property is absent", () => {
    expect(profileIdOf(fakeMp({}), 1)).toBeNull();
  });
});
