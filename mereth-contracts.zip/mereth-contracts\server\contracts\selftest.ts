// Proves the contract system against the real server rather than only against a simulator.
//
// Runs at gamemode load with no players connected, using actors placed for the purpose. The
// checks that matter are the money ones: coin conservation, and that an unfunded contract a
// client cannot pay produces a debt note instead of either an error or invented septims.

import type { MpApi } from "../mp";
import { coinHeldBy, giveCoin, giveItem, itemCount, takeItem, GOLD_FORM_ID } from "./escrow";
import { verifyContract, verifyDebtNote } from "./contract";
import {
  accept,
  allDebts,
  deliver,
  post,
  settle,
  allContracts,
  type ContractDeps,
} from "./service";

/** Player base record. mp.place builds a real MpActor when the base is an NPC_. */
const PLAYER_BASE = 0x00000007;
/** Verified against the form codex built from the installed masters. */
const IRON_INGOT = 0x0005ace4;

const HOUR_MS = 60 * 60 * 1000;

function placeActor(mp: MpApi): number {
  const placed: unknown = mp.place(PLAYER_BASE);
  const formId =
    typeof placed === "number" ? placed : Number((placed as { newFormId?: string | number })?.newFormId ?? Number.NaN);
  if (!Number.isFinite(formId)) throw new Error("mp.place did not return a usable form id");
  return formId >>> 0;
}

/**
 * A placed NPC arrives carrying the base record's default kit, including 140 gold and an
 * iron sword. The tests assert exact balances, so strip the actor to nothing first and
 * deal only in what we put there.
 */
function emptyPurse(mp: MpApi, holder: number): void {
  const coin = coinHeldBy(mp, holder);
  if (coin > 0) takeItem(mp, holder, GOLD_FORM_ID, coin);
  const ingots = itemCount(mp, holder, IRON_INGOT);
  if (ingots > 0) takeItem(mp, holder, IRON_INGOT, ingots);
}

export function runContractSelfTest(deps: ContractDeps): boolean {
  const mp = deps.mp;
  const results: boolean[] = [];
  const check = (label: string, passed: boolean): void => {
    deps.log((passed ? "  PASS  " : "  FAIL  ") + label);
    results.push(passed);
  };

  // ---- Case one: a funded goods contract, settled ------------------------------------
  const client = placeActor(mp);
  const worker = placeActor(mp);
  emptyPurse(mp, client);
  emptyPurse(mp, worker);
  giveCoin(mp, client, 500);
  giveItem(mp, worker, IRON_INGOT, 10);

  const coinBefore = coinHeldBy(mp, client) + coinHeldBy(mp, worker);
  check("test actors funded, 500 septims in play", coinBefore === 500);

  const posted = post(deps, client, {
    kind: "goods",
    title: "Forty ingots for the forge",
    body: "Ten iron ingots delivered to Warmaiden's before the week is out.",
    reward: 300,
    funding: "funded",
    deliverable: { formId: IRON_INGOT, count: 10, label: "Iron Ingot" },
    durationMs: 24 * HOUR_MS,
  });
  check("funded contract posted", posted.ok && posted.contract !== undefined);
  if (!posted.contract) return false;

  check("posting bound the coin, client down to 200", coinHeldBy(mp, client) === 200);
  check("contract verifies against its seal", verifyContract(posted.contract, deps.secret));

  check("the client cannot take their own contract", accept(deps, client, posted.contract.id).ok === false);
  check("a worker can accept", accept(deps, worker, posted.contract.id).ok);

  const delivered = deliver(deps, worker, posted.contract.id);
  check("delivery moved the goods and settled", delivered.ok && delivered.contract?.state === "settled");
  check("the worker was paid 300", coinHeldBy(mp, worker) === 300);
  check("the client received 10 ingots", itemCount(mp, client, IRON_INGOT) === 10);
  check("the worker gave up the ingots", itemCount(mp, worker, IRON_INGOT) === 0);

  // The invariant that matters more than any single feature.
  const coinAfter = coinHeldBy(mp, client) + coinHeldBy(mp, worker);
  check("no coin was created or destroyed", coinAfter === coinBefore);

  // ---- Case two: an unfunded contract the client cannot pay --------------------------
  const poorClient = placeActor(mp);
  const secondWorker = placeActor(mp);
  emptyPurse(mp, poorClient);
  emptyPurse(mp, secondWorker);
  giveCoin(mp, poorClient, 50);
  giveItem(mp, secondWorker, IRON_INGOT, 5);

  const promise = post(deps, poorClient, {
    kind: "goods",
    title: "Five ingots, paid on my word",
    body: "I am good for it. Ask anyone in Riverwood.",
    reward: 400,
    funding: "unfunded",
    deliverable: { formId: IRON_INGOT, count: 5, label: "Iron Ingot" },
    durationMs: 24 * HOUR_MS,
  });
  check("unfunded contract posted", promise.ok && promise.contract !== undefined);
  if (!promise.contract) return false;
  check("an unfunded contract binds no coin", poorClient !== 0 && coinHeldBy(mp, poorClient) === 50);

  accept(deps, secondWorker, promise.contract.id);
  const handedOver = deliver(deps, secondWorker, promise.contract.id);
  check("delivery on an unfunded contract awaits settlement", handedOver.contract?.state === "delivered");

  const settled = settle(deps, promise.contract.id);
  check("settling an unpayable promise defaults", settled.contract?.state === "defaulted");
  check("a debt note was issued", settled.debt !== undefined);
  check("the debt is the shortfall, 350", settled.debt?.amount === 350);
  check("the debt note verifies", settled.debt !== undefined && verifyDebtNote(settled.debt, deps.secret));
  check("the client paid what they had", coinHeldBy(mp, poorClient) === 0);
  check("the worker received the part payment", coinHeldBy(mp, secondWorker) === 50);
  check("the goods still changed hands", itemCount(mp, poorClient, IRON_INGOT) === 5);

  // ---- Case three: forging your own copy rewrites nothing -----------------------------
  //
  // Both parties hold a sealed copy. Writing a forged contract into the client's own
  // storage, past every server code path, must not change what the world believes: the
  // forged copy fails its seal and is dropped, and the counterparty's genuine copy stands.
  // That is what makes a contract evidence rather than a claim.
  const stored = deps.mp.get(client, "mrpContracts");
  const list = Array.isArray(stored) ? (stored as Array<Record<string, unknown>>) : [];
  const genuine = list.find((c) => c["id"] === posted.contract?.id);
  if (genuine) {
    const forged = { ...genuine, reward: 99999 };
    deps.mp.set(client, "mrpContracts", [...list.filter((c) => c["id"] !== genuine["id"]), forged]);

    const afterForgery = allContracts(deps).find((c) => c.id === posted.contract?.id);
    check("the forged copy does not survive its seal", afterForgery?.reward !== 99999);
    check("the counterparty's genuine copy stands", afterForgery?.reward === 300);
    check("and it still verifies", afterForgery !== undefined && verifyContract(afterForgery, deps.secret));

    deps.mp.set(client, "mrpContracts", list);
  } else {
    check("could read the stored contract for the forgery check", false);
  }

  const debts = allDebts(deps);
  check("the debt survived storage", debts.length === 1 && debts[0]?.amount === 350);

  const passed = results.filter(Boolean).length;
  deps.log(`[contracts] self-test ${passed}/${results.length} passed`);
  deps.log(passed === results.length ? "[contracts] CONTRACTS OK" : "[contracts] CONTRACTS FAILED");
  return passed === results.length;
}

export { GOLD_FORM_ID };
