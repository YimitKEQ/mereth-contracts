// Contracts wired to SkyMP: storage, escrow movement, and the order operations happen in.
//
// The ordering rules here are the whole safety story, because coin movement is not
// transactional and a crash between two steps must never leave septims invented or lost:
//
//   POSTING   take the coin FIRST, then create the contract. If the take fails there is no
//             contract, which is recoverable. A contract nobody can pay is not.
//   SETTLING  move the coin FIRST, then record the settlement. A payment that happened
//             without a record can be reconciled from the history; a record claiming a
//             payment that never moved cannot.
//   REFUNDING same order, coin then record.
//
// Storage: contracts live in one server-owned property per participant, so a player's own
// client can render their contracts, and nobody else's. The board itself is a separate
// server-wide property, since open contracts are public by design.

import { getMp, type MpApi } from "../mp";
import {
  acceptContract,
  expireContract,
  reviewWindowElapsed,
  markDelivered,
  postContract,
  rejectDelivery,
  settleContract,
  validateDraft,
  verifyContract,
  withdrawContract,
  type Contract,
  type DebtNote,
  type Outcome,
  type Party,
} from "./contract";
import { checkGoods, coinHeldBy, giveCoin, takeCoin, transferGoods } from "./escrow";
import { actorIdOf, characterName } from "./identity";

/** Contracts a character is party to. Stored on the character, so it persists with them. */
export const BOARD_PROPERTY = "mrpContracts";
/** Debt notes, held by both parties so either can produce one as evidence. */
export const DEBT_PROPERTY = "mrpDebts";

export interface ContractDeps {
  mp: MpApi;
  secret: string;
  now: () => number;
  nextId: (prefix: string) => string;
  log: (message: string) => void;
  /**
   * Every character the server has seen hold a contract this session.
   *
   * There is deliberately no server-wide anchor form: `mp.set` needs an instantiated form,
   * and form 0x14 (the player) does not exist with nobody connected, which is exactly how
   * the first attempt failed. Storing on the participants is also the correct model, since
   * a character's contracts persist as part of that character's ChangeForm.
   */
  participants: Set<number>;
}

function readFrom<T>(deps: ContractDeps, holder: number, property: string): T[] {
  try {
    const raw = deps.mp.get(holder, property);
    return Array.isArray(raw) ? (raw as T[]) : [];
  } catch {
    // A form that has gone away is not an error, it just holds nothing.
    return [];
  }
}

function writeTo<T>(deps: ContractDeps, holder: number, property: string, list: T[]): void {
  deps.mp.set(holder, property, list);
  deps.participants.add(holder);
}

/** Stored records are only as trustworthy as the database, so anything unsealed is dropped. */
export function allContracts(deps: ContractDeps): Contract[] {
  const byId = new Map<string, Contract>();
  for (const holder of deps.participants) {
    for (const c of readFrom<Contract>(deps, holder, BOARD_PROPERTY)) {
      // Both parties hold a copy, so dedupe and keep whichever is verifiable.
      if (verifyContract(c, deps.secret)) byId.set(c.id, c);
    }
  }
  return [...byId.values()];
}

export function allDebts(deps: ContractDeps): DebtNote[] {
  const byId = new Map<string, DebtNote>();
  for (const holder of deps.participants) {
    for (const d of readFrom<DebtNote>(deps, holder, DEBT_PROPERTY)) byId.set(d.id, d);
  }
  return [...byId.values()];
}

/** Writes the contract to every party, so either can produce it independently. */
function saveContract(deps: ContractDeps, updated: Contract): void {
  const holders = [updated.client.formId, ...(updated.worker ? [updated.worker.formId] : [])];
  for (const holder of holders) {
    const list = readFrom<Contract>(deps, holder, BOARD_PROPERTY);
    const at = list.findIndex((c) => c.id === updated.id);
    writeTo(deps, holder, BOARD_PROPERTY, at === -1 ? [...list, updated] : list.map((c, i) => (i === at ? updated : c)));
  }
}

function saveDebt(deps: ContractDeps, note: DebtNote): void {
  for (const holder of [note.debtor.formId, note.creditor.formId]) {
    const list = readFrom<DebtNote>(deps, holder, DEBT_PROPERTY);
    if (list.some((d) => d.id === note.id)) continue;
    writeTo(deps, holder, DEBT_PROPERTY, [...list, note]);
  }
}

function partyOf(deps: ContractDeps, formId: number): Party {
  // The character, not the account. actorIdOf makes that explicit at the one place a party
  // is built, so nothing downstream has to remember the rule.
  return { formId, actorId: actorIdOf(formId), name: characterName(deps.mp, formId) };
}

export interface Result {
  ok: boolean;
  error?: string;
  contract?: Contract;
  debt?: DebtNote;
}

function fail(error: string): Result {
  return { ok: false, error };
}

/** Post a contract. For a funded one the coin is bound before the record exists. */
export function post(deps: ContractDeps, clientFormId: number, input: unknown): Result {
  let draft;
  try {
    draft = validateDraft(input);
  } catch (error) {
    return fail(error instanceof Error ? error.message : String(error));
  }

  let escrowTaken = 0;
  if (draft.funding === "funded") {
    if (draft.reward === 0) return fail("a funded contract needs a reward above zero");
    const held = coinHeldBy(deps.mp, clientFormId);
    if (held < draft.reward) return fail(`you hold ${held} septims but the reward is ${draft.reward}`);
    try {
      escrowTaken = takeCoin(deps.mp, clientFormId, draft.reward);
    } catch (error) {
      return fail(`could not bind the coin: ${error instanceof Error ? error.message : String(error)}`);
    }
    if (escrowTaken !== draft.reward) return fail("could not bind the full reward");
  }

  const contract = postContract(
    draft,
    partyOf(deps, clientFormId),
    deps.nextId("con"),
    deps.now(),
    escrowTaken,
    deps.secret,
  );
  saveContract(deps, contract);
  deps.log(`[contracts] posted ${contract.id} (${contract.funding}, ${contract.reward} septims)`);
  return { ok: true, contract };
}

function find(deps: ContractDeps, id: unknown): Contract | null {
  if (typeof id !== "string" || id === "") return null;
  return allContracts(deps).find((c) => c.id === id) ?? null;
}

/**
 * Run one transition and commit it.
 *
 * Every simple transition is the same six steps, and the order inside them is the entire
 * safety story: the coin moves BEFORE the record is written, because a payment that happened
 * without a record can be reconciled from the history, and a record claiming a payment that
 * never moved cannot. Writing that out per call site is three chances to get it backwards, so
 * it lives here once.
 */
function apply(deps: ContractDeps, id: unknown, transition: (c: Contract) => Outcome): Result {
  const contract = find(deps, id);
  if (!contract) return fail("no such contract");

  const outcome = transition(contract);
  if (!outcome.ok) return fail(outcome.refusal ?? "refused");

  if (outcome.refund) giveCoin(deps.mp, contract.client.formId, outcome.refund);
  saveContract(deps, outcome.contract);
  return { ok: true, contract: outcome.contract };
}

export function accept(deps: ContractDeps, workerFormId: number, id: unknown): Result {
  return apply(deps, id, (c) =>
    acceptContract(c, partyOf(deps, workerFormId), deps.now(), deps.secret),
  );
}

/** Only while nobody has taken it, which the engine enforces. Returns any escrow. */
export function withdraw(deps: ContractDeps, byFormId: number, id: unknown): Result {
  return apply(deps, id, (c) => withdrawContract(c, byFormId, deps.secret));
}

/**
 * Deliver. For a goods contract the server moves and RECOUNTS the items itself, so a client
 * claiming delivery it never made is refused by arithmetic rather than by trust.
 */
export function deliver(deps: ContractDeps, workerFormId: number, id: unknown): Result {
  const contract = find(deps, id);
  if (!contract) return fail("no such contract");
  if (contract.worker === null || contract.worker.formId !== workerFormId) {
    return fail("not-the-worker");
  }

  if (contract.kind === "goods" && contract.deliverable) {
    const { formId, count, label } = contract.deliverable;
    const check = checkGoods(deps.mp, workerFormId, formId, count);
    if (!check.ok) return fail(`you are carrying ${check.held} of ${count} ${label}`);
    if (!transferGoods(deps.mp, workerFormId, contract.client.formId, formId, count)) {
      return fail("the goods could not be handed over");
    }
  }

  const outcome = markDelivered(contract, workerFormId, deps.now(), deps.secret);
  if (!outcome.ok) {
    // The goods already moved, so refusing now would lose them. This should be unreachable
    // because the guards above mirror the state machine's, and it is logged loudly if not.
    deps.log(`[contracts] DELIVERY DESYNC on ${contract.id}: ${String(outcome.refusal)}`);
    return fail(outcome.refusal ?? "refused");
  }
  saveContract(deps, outcome.contract);

  // Goods settle themselves, because the server counted the items into the client's hands a
  // few lines above. There is nothing left to take anyone's word about.
  //
  // A SERVICE does not, even when it is funded. Nothing was verified, so letting the worker
  // settle by declaring themselves finished would let anyone take a funded job, claim it done
  // and walk off with the escrow. It waits for the client, and releases on its own if they
  // never look. See REVIEW_WINDOW_MS.
  if (outcome.contract.funding === "funded" && outcome.contract.kind === "goods") {
    return settle(deps, outcome.contract.id);
  }
  return { ok: true, contract: outcome.contract };
}

export function settle(deps: ContractDeps, id: unknown): Result {
  const contract = find(deps, id);
  if (!contract) return fail("no such contract");
  if (contract.worker === null) return fail("nobody accepted this contract");

  const clientCoin = contract.funding === "unfunded" ? coinHeldBy(deps.mp, contract.client.formId) : 0;
  const outcome = settleContract(contract, deps.now(), clientCoin, deps.nextId("debt"), deps.secret);
  if (!outcome.ok) return fail(outcome.refusal ?? "refused");

  // Coin first. A payment without a record is reconcilable; a record without a payment is not.
  if (outcome.payout) {
    if (contract.funding === "unfunded") takeCoin(deps.mp, contract.client.formId, outcome.payout);
    giveCoin(deps.mp, contract.worker.formId, outcome.payout);
  }
  saveContract(deps, outcome.contract);

  if (outcome.debt) {
    saveDebt(deps, outcome.debt);
    deps.log(
      `[contracts] ${contract.id} defaulted, ${outcome.debt.amount} septims owed by ${contract.client.name}`,
    );
  }
  return { ok: true, contract: outcome.contract, ...(outcome.debt ? { debt: outcome.debt } : {}) };
}

/** The client refuses the delivery. Recorded against BOTH parties, judged by neither. */
export function reject(deps: ContractDeps, byFormId: number, id: unknown): Result {
  return apply(deps, id, (c) => rejectDelivery(c, byFormId, deps.secret));
}

/** Sweep lapsed contracts. Safe to call repeatedly: terminal ones are skipped. */
export function sweepExpired(deps: ContractDeps): number {
  const now = deps.now();
  let swept = 0;
  for (const contract of allContracts(deps)) {
    const outcome = expireContract(contract, now, deps.secret);
    if (!outcome.ok) continue;
    if (outcome.refund) giveCoin(deps.mp, contract.client.formId, outcome.refund);
    saveContract(deps, outcome.contract);
    swept += 1;
  }
  if (swept > 0) deps.log(`[contracts] swept ${swept} lapsed`);
  return swept;
}

/**
 * Release escrow on delivered work the client never answered for.
 *
 * The counterpart to sweepExpired: that one protects a client whose worker vanished, this one
 * protects a worker whose client did. Silence is not a refusal, so after the review window the
 * coin goes to the person who did the job.
 */
export function sweepDelivered(deps: ContractDeps): number {
  const now = deps.now();
  let released = 0;
  for (const contract of allContracts(deps)) {
    if (!reviewWindowElapsed(contract, now)) continue;
    const outcome = settle(deps, contract.id);
    if (!outcome.ok) continue;
    released += 1;
    deps.log(`[contracts] ${contract.id} released to the worker, the client did not answer`);
  }
  if (released > 0) deps.log(`[contracts] released ${released} unanswered`);
  return released;
}

export interface Summary {
  open: number;
  accepted: number;
  delivered: number;
  settled: number;
  rejected: number;
  expired: number;
  withdrawn: number;
  defaulted: number;
  escrowHeld: number;
  debtOutstanding: number;
}

export function summarise(deps: ContractDeps): Summary {
  const contracts = allContracts(deps);
  const summary: Summary = {
    open: 0,
    accepted: 0,
    delivered: 0,
    settled: 0,
    rejected: 0,
    expired: 0,
    withdrawn: 0,
    defaulted: 0,
    escrowHeld: 0,
    debtOutstanding: 0,
  };
  for (const c of contracts) {
    summary[c.state] += 1;
    summary.escrowHeld += c.escrow;
  }
  for (const d of allDebts(deps)) summary.debtOutstanding += d.amount;
  return summary;
}

/**
 * Declare the properties before anything touches them.
 *
 * `mp.get` and `mp.set` throw "Property 'x' doesn't exist" on an undeclared name, which is
 * a good default: it means a typo fails loudly instead of silently writing nowhere.
 *
 * Both are visible to the owner so a player's own client can render their contracts, and
 * hidden from neighbours, because who holds which contract is not public knowledge. The
 * open board is a separate concern from what a given character is carrying.
 */
export function registerContracts(deps: ContractDeps): void {
  for (const name of [BOARD_PROPERTY, DEBT_PROPERTY]) {
    deps.mp.makeProperty(name, {
      isVisibleByOwner: true,
      isVisibleByNeighbors: false,
      updateOwner: "",
      updateNeighbor: "",
    });
  }
  deps.log("[contracts] properties registered");
}

export function makeDeps(secret: string, log: (message: string) => void): ContractDeps {
  let counter = 1;
  return {
    mp: getMp(),
    secret,
    now: () => Date.now(),
    nextId: (prefix: string) => `${prefix}-${String(counter++).padStart(5, "0")}`,
    log,
    participants: new Set<number>(),
  };
}
