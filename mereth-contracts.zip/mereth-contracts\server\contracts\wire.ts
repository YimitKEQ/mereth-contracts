// Bringing contracts into the running game.
//
// contract.ts is the engine and service.ts moves the coin. Neither of them can be reached
// by a player: this file is the surface. It owns three things and nothing else.
//
//   1. WHO IS HERE. The service stores contracts on the participants, so it needs to be told
//      which form id belongs to which connected user. Only the server knows that mapping.
//   2. WHAT A PLAYER SEES. One property per player, pushed to their client, holding their own
//      contracts plus the public board. Deliberately a trimmed projection, not the sealed
//      records: a client has no use for a seal and no business holding somebody else's.
//   3. WHAT A PLAYER MAY ASK FOR. One event source, one handler, every field treated as
//      hostile. The client names an action and a contract id. It never names the actor: that
//      comes from the connection, so a player cannot act as somebody else.
//
// The channel in each direction is worth spelling out, because it is not obvious and the
// documentation is thin:
//
//   SERVER -> CLIENT   `updateOwner` is a STRING of client-side JavaScript that the client
//                      runs every frame for the owning player. It gets `ctx.value` (the
//                      property) and `ctx.state` (a scratch object that survives between
//                      frames). Nothing from this module's scope exists inside it. Because it
//                      runs at frame rate, it compares a revision number and does nothing at
//                      all in the common case.
//
//   CLIENT -> SERVER   `makeEventSource` is the same idea in reverse: client JS that calls
//                      `ctx.sendEvent(...)`, which arrives at `mp[eventName]` with the
//                      caller's form id prepended by the server. Two sources feed it, the
//                      in-game browser and a shared-storage outbox, so the feature works
//                      whether or not the companion plugin is installed.

import type { MpApi } from "../mp";
import type { Contract, DebtNote } from "./contract";
import { actorIdOf, characterName } from "./identity";
import {
  accept,
  allContracts,
  allDebts,
  deliver,
  post,
  reject,
  settle,
  summarise,
  withdraw,
  type ContractDeps,
  type Result,
} from "./service";

/** What a player's client is given. Never the sealed records. */
export /**
 * Where the player is, as a hold name, written by the host when a board is used.
 *
 * Contracts do not try to work this out themselves. The missive board in Falkreath knows it
 * is in Falkreath; a pile of coordinates does not.
 */
const HOLD_PROPERTY = "mereth:hold";

export const VIEW_PROPERTY = "mrpView";
/** The event the client raises to ask for something. */
export const ACTION_EVENT = "_mrpContractAction";
/**
 * Scratch keys inside the SkyMP client's plugin.
 *
 * Skyrim Platform's `storage` is per plugin, not shared across the process, so these are only
 * ever visible to code the server pushes. That is exactly who uses them: updateOwner writes
 * the view, the hotkey handler reads it, and the eval channel writes the outbox.
 */
const OUTBOX_KEY = "mereth:outbox";
const VIEW_KEY = "mereth:view";

// ---------------------------------------------------------------------------
// The projection a client receives.
// ---------------------------------------------------------------------------

/** A contract as the board shows it. No seal, no history, no counterparty internals. */
export interface PublicContract {
  id: string;
  kind: Contract["kind"];
  title: string;
  body: string;
  reward: number;
  funding: Contract["funding"];
  state: Contract["state"];
  clientName: string;
  clientId: number;
  workerName: string | null;
  workerId: number | null;
  deadline: number;
  postedAt: number;
  escrow: number;
  /** The hold whose board carries this. Null means it was posted without one. */
  hold: string | null;
  deliverable: Contract["deliverable"];
}

export interface PublicDebt {
  id: string;
  contractId: string;
  debtorName: string;
  creditorName: string;
  amount: number;
  incurredAt: number;
}

export interface PlayerView {
  /** Bumped on every change. The client compares this and nothing else, every frame. */
  rev: number;
  /**
   * The player themselves.
   *
   * `actorId` is the character and is what every contract binds to, online or offline. The
   * account behind it is deliberately absent: it is account wide, so surfacing it invites a
   * client to key on the wrong thing.
   */
  self: { formId: number; actorId: number; name: string; coin: number; hold: string | null };
  /**
   * Open contracts on the board the player is standing at.
   *
   * A contract belongs to the hold whose board it was pinned at, so this is scoped rather
   * than global. With no hold set it falls back to everything, which is what a caller that
   * has not wired boards up yet sees.
   */
  board: PublicContract[];
  /** Every hold with open work, and how much, so a board can show the other tabs' counts. */
  boards: Array<{ hold: string; open: number }>;
  /** Contracts this player is a party to, in any state. */
  mine: PublicContract[];
  debts: PublicDebt[];
  summary: ReturnType<typeof summarise>;
  /** The result of this player's last action, so the UI can say what happened. */
  notice: { ok: boolean; text: string; at: number } | null;
  serverTime: number;
}

function project(c: Contract): PublicContract {
  return {
    id: c.id,
    kind: c.kind,
    title: c.title,
    body: c.body,
    reward: c.reward,
    funding: c.funding,
    hold: c.hold,
    state: c.state,
    clientName: c.client.name,
    clientId: c.client.formId,
    workerName: c.worker ? c.worker.name : null,
    workerId: c.worker ? c.worker.formId : null,
    deadline: c.deadline,
    postedAt: c.postedAt,
    escrow: c.escrow,
    deliverable: c.deliverable,
  };
}

function projectDebt(d: DebtNote): PublicDebt {
  return {
    id: d.id,
    contractId: d.contractId,
    debtorName: d.debtor.name,
    creditorName: d.creditor.name,
    amount: d.amount,
    incurredAt: d.incurredAt,
  };
}

// ---------------------------------------------------------------------------
// Client-side source. These are strings, and they run in the game, not here.
// ---------------------------------------------------------------------------

/**
 * Runs every frame for the owning player, which is why the first thing it does is leave.
 *
 * Comparing a revision integer rather than re-serialising the view is the difference between
 * a property that costs nothing and one that costs a frame. The push itself is two writes:
 * the browser, for the real UI, and shared storage, so a companion plugin can render the
 * same data without the server needing to know whether one is installed.
 */
const UPDATE_OWNER = `
  if (ctx.value && ctx.state.mrpRev !== ctx.value.rev) {
    ctx.state.mrpRev = ctx.value.rev;
    var v = ctx.value;
    var json = JSON.stringify(v);

    // A file line, so "did the push actually arrive" is answerable from a terminal instead
    // of by inference. This is the only signal that crosses the process boundary.
    try { ctx.sp.writeLogs("mereth-channel", "view rev " + v.rev + " arrived on the client"); } catch (e) {}

    // Delivery into the browser, in two shapes, and NEITHER of them takes the browser over.
    //
    // A server that already runs its own interface owns that surface. Mereth's client calls
    // browser.loadUrl and browser.setVisible dozens of times to drive a React bundle of its
    // own, so anything here that loaded a page would wipe their UI off the screen. Both calls
    // below are no-ops when nothing is listening.
    //
    //   window.mereth.onView   the standalone board shipped in Data/Platform/UI/mereth
    //   CustomEvent            how Mereth's own UI already receives server data, verified
    //                          against their published client bundle
    try {
      ctx.sp.browser.executeJavaScript(
        "(function(){try{" +
          "window.mereth && window.mereth.onView && window.mereth.onView(" + json + ");" +
          "window.dispatchEvent(new CustomEvent('mereth:contracts',{detail:" + json + "}));" +
        "}catch(e){}})()"
      );
    } catch (e) {}

    // A readable summary in the ~ console, for players whose Chromium is unavailable and as
    // the plain-text record of what the server told this client.
    try {
      ctx.sp.printConsole("[mereth] " + v.self.name + ", " + v.self.coin + " septims, "
        + v.board.length + " on the board, " + v.mine.length + " of yours");
      for (var i = 0; i < v.board.length && i < 6; i++) {
        var c = v.board[i];
        ctx.sp.printConsole("[mereth] " + c.id + " " + c.title + " (" + c.reward + ", " + c.funding + ")");
      }
      if (v.notice) ctx.sp.printConsole("[mereth] " + (v.notice.ok ? "" : "refused: ") + v.notice.text);
    } catch (e) {}

    // Kept for the hotkey handler below, which runs in this same plugin and needs the last
    // view to know which contract a key applies to.
    try { ctx.sp.storage[${JSON.stringify(VIEW_KEY)}] = v; } catch (e) {}
  }
`;

/**
 * Two ways in, because the feature must not depend on a client-side install.
 *
 * The browser path is the real one: the UI posts a message and it arrives here. The storage
 * path exists so the companion plugin's console commands, and the acceptance harness, can
 * drive the same handler. Storage is shared between every plugin in the process, which is
 * exactly what makes it a usable bus and exactly why the key is namespaced.
 *
 * Reading an UNSET storage key returns a function rather than undefined, so the Array.isArray
 * guard is load bearing and not defensive noise.
 */
const ACTION_SOURCE = `
  ctx.sp.on("browserMessage", function (e) {
    try {
      var a = e.arguments;
      if (!a || a[0] !== "mereth:contract") return;
      ctx.sendEvent(a[1]);
    } catch (err) {}
  });

  // Hotkeys, which are the input surface that actually survives contact with a multiplayer
  // client. The console is a poor fit here: SkyMP owns it, borrowing a command means
  // inheriting whatever parameter schema the borrowed command had, and it demands typing.
  // Skyrim Platform's buttonEvent is hooked well below the game's own UI, so it fires whether
  // or not a menu is up and whatever SkyMP is doing with input.
  //
  // updateOwner and this event source both execute inside the SkyMP client's plugin, so they
  // share that plugin's storage. That is what lets this read the view the push just wrote,
  // without needing any of it sent back down.
  ctx.sp.on("buttonEvent", function (e) {
    try {
      if (!e.isDown || e.isRepeating) return;
      var keys = { 59: "board", 60: "accept", 61: "deliver", 62: "settle", 63: "withdraw" };
      var verb = keys[e.code];
      if (!verb) return;

      var view = ctx.sp.storage[${JSON.stringify(VIEW_KEY)}];
      if (!view || typeof view !== "object") {
        ctx.sp.printConsole("[mereth] no board yet, waiting for the server");
        return;
      }
      if (verb === "board") {
        ctx.sendEvent({ action: "refresh" });
        return;
      }

      // Pick the contract each verb can actually apply to, so a hotkey never needs an id.
      var me = view.self && view.self.formId;
      var target = null;
      var list = (verb === "accept") ? (view.board || []) : (view.mine || []);
      for (var i = 0; i < list.length; i++) {
        var c = list[i];
        if (verb === "accept" && c.state === "open" && c.clientId !== me) { target = c; break; }
        if (verb === "deliver" && c.state === "accepted" && c.workerId === me) { target = c; break; }
        if (verb === "settle" && c.state === "delivered" && c.clientId === me) { target = c; break; }
        if (verb === "withdraw" && c.state === "open" && c.clientId === me) { target = c; break; }
      }
      if (!target) {
        ctx.sp.printConsole("[mereth] nothing to " + verb);
        return;
      }
      ctx.sp.printConsole("[mereth] " + verb + " " + target.id + " (" + target.title + ")");
      ctx.sendEvent({ action: verb, id: target.id });
    } catch (err) {}
  });

  ctx.sp.on("update", function () {
    try {
      var box = ctx.sp.storage[${JSON.stringify(OUTBOX_KEY)}];
      if (!Array.isArray(box) || box.length === 0) return;
      ctx.sp.storage[${JSON.stringify(OUTBOX_KEY)}] = [];
      for (var i = 0; i < box.length; i++) ctx.sendEvent(box[i]);
    } catch (err) {}
  });

`;

// ---------------------------------------------------------------------------
// Presence. The service needs form ids; only the connection knows them.
// ---------------------------------------------------------------------------

export interface WireState {
  /** User ids currently connected. Actors are resolved fresh, since they spawn later. */
  users: Set<number>;
  /** Last action result per player, so a refusal can be shown to the player who caused it. */
  notices: Map<number, { ok: boolean; text: string; at: number }>;
  /**
   * What each player was last actually sent, minus the fields that change on their own.
   *
   * This is what lets the refresh loop run on a timer without defeating the point of the
   * revision guard: a player whose view has not changed is not written to at all, so their
   * client never re-renders and the property never churns the database.
   */
  lastSent: Map<number, string>;
  rev: number;
}

export function makeWireState(): WireState {
  return { users: new Set<number>(), notices: new Map(), lastSent: new Map(), rev: 1 };
}

/** A connected user's actor, or null while they are still loading in. */
function actorOf(mp: MpApi, userId: number): number | null {
  try {
    const raw = (mp as unknown as { getUserActor(id: number): unknown }).getUserActor(userId);
    const formId = Number(raw);
    // 0 is what the server reports for a user who has connected but not yet spawned.
    return Number.isFinite(formId) && formId > 0 ? formId >>> 0 : null;
  } catch {
    return null;
  }
}

function coinOf(deps: ContractDeps, formId: number): number {
  try {
    const raw = deps.mp.get(formId, "inventory");
    const entries = (raw as { entries?: unknown })?.entries;
    if (!Array.isArray(entries)) return 0;
    return entries.reduce(
      (sum: number, e: unknown) =>
        (e as { baseId?: number })?.baseId === 0x0000000f ? sum + Number((e as { count?: number }).count ?? 0) : sum,
      0,
    );
  } catch {
    return 0;
  }
}



/**
 * What a board in `hold` shows.
 *
 * Scoped to where the player is standing. A contract posted without a hold is visible
 * everywhere, which is what makes this safe to switch on before every board has been wired
 * up: nothing disappears, things only start being local as holds get set.
 *
 * Exported and pure so the rule can be tested without standing up a server.
 */
export function visibleOnBoard<T extends { hold: string | null }>(
  open: readonly T[],
  hold: string | null,
): T[] {
  if (hold === null) return [...open];
  return open.filter((c) => c.hold === hold || c.hold === null);
}

/**
 * Which hold this player counts as standing in.
 *
 * Deliberately a property the host sets rather than something derived from coordinates here.
 * The board a player walked up to knows its own hold, and reading it from the interaction is
 * both simpler and correct, where guessing a hold from an x and a y is neither.
 */
export function holdOf(deps: ContractDeps, formId: number): string | null {
  try {
    const raw = deps.mp.get(formId, HOLD_PROPERTY);
    return typeof raw === "string" && raw.trim() !== "" ? raw.trim() : null;
  } catch {
    return null;
  }
}

/** Build one player's view. Everything public in this hold, plus everything of theirs. */
export function viewFor(deps: ContractDeps, state: WireState, formId: number): PlayerView {
  const contracts = allContracts(deps);
  const mine = contracts.filter((c) => c.client.formId === formId || c.worker?.formId === formId);
  const open = contracts.filter((c) => c.state === "open");
  const hold = holdOf(deps, formId);

  const board = visibleOnBoard(open, hold);

  const counts = new Map<string, number>();
  for (const c of open) {
    if (c.hold === null) continue;
    counts.set(c.hold, (counts.get(c.hold) ?? 0) + 1);
  }

  const debts = allDebts(deps).filter((d) => d.debtor.formId === formId || d.creditor.formId === formId);

  return {
    rev: state.rev,
    self: {
      formId,
      actorId: actorIdOf(formId),
      name: characterName(deps.mp, formId),
      coin: coinOf(deps, formId),
      hold,
    },
    board: board.map(project),
    boards: [...counts.entries()].sort((a, b) => b[1] - a[1]).map(([h, o]) => ({ hold: h, open: o })),
    mine: mine.map(project),
    debts: debts.map(projectDebt),
    summary: summarise(deps),
    notice: state.notices.get(formId) ?? null,
    serverTime: Date.now(),
  };
}

/** Everything that should NOT count as a change, because it moves on its own. */
function fingerprint(view: PlayerView): string {
  return JSON.stringify({ ...view, rev: 0, serverTime: 0 });
}

/**
 * Push a fresh view to every player whose view actually changed.
 *
 * Called both after an action and on a timer. The timer matters because a player is not
 * spawned yet when `connect` fires, and because coin can move for reasons that have nothing
 * to do with contracts. The change check matters because without it the timer would bump the
 * revision every tick and the client would re-render forever.
 *
 * A player whose actor has not spawned is skipped rather than treated as an error. They get
 * the current view on the next pass.
 */
export function pushViews(deps: ContractDeps, state: WireState): number {
  let pushed = 0;
  for (const userId of state.users) {
    const formId = actorOf(deps.mp, userId);
    if (formId === null) continue;
    // A player holding a contract must be a known participant, or their own records would
    // not be found on the next read.
    deps.participants.add(formId);

    const view = viewFor(deps, state, formId);
    const print = fingerprint(view);
    if (state.lastSent.get(formId) === print) continue;

    state.rev += 1;
    try {
      deps.mp.set(formId, VIEW_PROPERTY, { ...view, rev: state.rev });
      state.lastSent.set(formId, print);
      pushed += 1;
    } catch (error) {
      deps.log("[contracts] could not push a view to 0x" + formId.toString(16) + ": " + String(error));
    }
  }
  return pushed;
}

// ---------------------------------------------------------------------------
// The one handler. Everything below this line treats its input as hostile.
// ---------------------------------------------------------------------------

export type ActionName = "post" | "accept" | "withdraw" | "deliver" | "settle" | "reject" | "refresh";

const ACTIONS: ReadonlySet<string> = new Set<string>([
  "post",
  "accept",
  "withdraw",
  "deliver",
  "settle",
  "reject",
  "refresh",
]);

/** Refusals are machine names. A player should be told what happened in words. */
const REFUSAL_TEXT: Record<string, string> = {
  "not-open": "that contract is no longer open",
  "not-accepted": "nobody has taken that contract",
  "not-delivered": "that work has not been delivered yet",
  "not-the-client": "only the client who posted it can do that",
  "not-the-worker": "only the worker who took it can do that",
  "client-cannot-take-own-contract": "you cannot take your own contract",
  "past-deadline": "the deadline has passed",
  "already-terminal": "that contract is already closed",
  tampered: "that record does not verify and has been refused",
};

function speak(result: Result, action: string): string {
  if (result.ok) {
    if (action === "post") return "contract posted";
    if (action === "accept") return "contract taken, the clock is running";
    if (action === "withdraw") return "contract withdrawn, any escrow returned";
    if (action === "deliver") return "delivery recorded";
    if (action === "settle") {
      return result.debt
        ? "the client could not pay in full, a debt note was written for " + result.debt.amount + " septims"
        : "settled and paid";
    }
    if (action === "reject") return "delivery refused, escrow returned";
    return "done";
  }
  const error = result.error ?? "refused";
  return REFUSAL_TEXT[error] ?? error;
}

export interface WireDeps {
  contracts: ContractDeps;
  state: WireState;
}

/**
 * Run one action on behalf of one actor.
 *
 * `formId` comes from the connection and never from the payload. That single rule is what
 * stops a player from posting, accepting or settling as somebody else, and it is why the
 * client is never asked who it is.
 */
export function handleAction(wire: WireDeps, formId: number, payload: unknown): Result {
  const { contracts, state } = wire;

  if (typeof payload !== "object" || payload === null) {
    return { ok: false, error: "malformed request" };
  }
  const raw = payload as Record<string, unknown>;
  const action = raw["action"];
  if (typeof action !== "string" || !ACTIONS.has(action)) {
    return { ok: false, error: "unknown action" };
  }

  // A player who acts is a participant, whether or not they already hold anything.
  contracts.participants.add(formId);

  let result: Result;
  switch (action) {
    case "post":
      result = post(contracts, formId, raw["draft"]);
      break;
    case "accept":
      result = accept(contracts, formId, raw["id"]);
      break;
    case "withdraw":
      result = withdraw(contracts, formId, raw["id"]);
      break;
    case "deliver":
      result = deliver(contracts, formId, raw["id"]);
      break;
    case "reject":
      result = reject(contracts, formId, raw["id"]);
      break;
    case "settle": {
      // Settling pays out, so only the client who owes the coin may trigger it.
      const target = allContracts(contracts).find((c) => c.id === raw["id"]);
      if (!target) {
        result = { ok: false, error: "no such contract" };
        break;
      }
      if (target.client.formId !== formId) {
        result = { ok: false, error: "not-the-client" };
        break;
      }
      result = settle(contracts, raw["id"]);
      break;
    }
    default:
      // "refresh" is the player asking to be told again. Forgetting what they were last sent
      // is what makes the next push actually happen: without this the change guard correctly
      // decides nothing has changed and says nothing, which reads as the command being dead.
      state.lastSent.delete(formId);
      result = { ok: true };
      break;
  }

  state.notices.set(formId, { ok: result.ok, text: speak(result, action), at: Date.now() });
  if (!result.ok) {
    contracts.log("[contracts] refused " + action + " for 0x" + formId.toString(16) + ": " + String(result.error));
  }
  pushViews(contracts, state);
  return result;
}

/**
 * Declare the view property and the action channel. Called once, at startup.
 *
 * This requires `enableGamemodeDataUpdatesBroadcast: true` in server-settings.json, and that
 * setting is the whole ballgame. Without it the server logs
 *
 *   PartOne::NotifyGamemodeApiStateChanged - skipping gamemode data update send,
 *   clientside hot-reload is disabled
 *
 * and never sends any client the `updateOwner` bodies or event sources declared here. The
 * channel is then silently dead: no error on either side, the client simply never learns
 * these properties exist. The setting name appears only as a string inside scam_native.node.
 *
 * With it on, a client joining long after startup is handed the current gamemode data
 * automatically, so there is nothing to re-declare per connection. `makeProperty` refuses a
 * name it already holds anyway.
 */
function declareChannel(mp: MpApi): void {
  mp.makeProperty(VIEW_PROPERTY, {
    isVisibleByOwner: true,
    isVisibleByNeighbors: false,
    updateOwner: UPDATE_OWNER,
    updateNeighbor: "",
  });
  mp.makeEventSource(ACTION_EVENT, ACTION_SOURCE);
}

/**
 * Open the channel and start tracking who is connected.
 *
 * Called once at startup, after registerContracts has declared the storage properties.
 */
export function registerWire(contracts: ContractDeps, state: WireState): WireDeps {
  const mp = contracts.mp;
  const wire: WireDeps = { contracts, state };

  declareChannel(mp);
  (mp as unknown as Record<string, unknown>)[ACTION_EVENT] = (pcFormId: number, payload: unknown): void => {
    try {
      handleAction(wire, pcFormId >>> 0, payload);
    } catch (error) {
      // A thrown handler would take the event loop down with it, and a malformed packet is
      // an expected thing to receive, not an exceptional one.
      contracts.log("[contracts] action threw: " + String(error));
    }
  };

  const on = (mp as unknown as { on(event: string, fn: (...args: never[]) => void): void }).on;
  if (typeof on === "function") {
    on.call(mp, "connect", ((userId: number) => {
      state.users.add(userId);
      contracts.log("[contracts] user " + userId + " connected");
      // Nothing to re-declare here. With enableGamemodeDataUpdatesBroadcast on, the server
      // hands a joining client the current gamemode data by itself, and makeProperty refuses
      // a name it already holds. Verified: a client connecting long after startup receives
      // the view property and the event source without any prompting.
      //
      // The actor does not exist yet at connect time, so the first useful push happens on
      // the next tick of the refresh loop rather than here.
    }) as never);
    on.call(mp, "disconnect", ((userId: number) => {
      state.users.delete(userId);
      contracts.log("[contracts] user " + userId + " disconnected");
    }) as never);
  }

  contracts.log("[contracts] wire registered, view property and action channel are live");
  return wire;
}
