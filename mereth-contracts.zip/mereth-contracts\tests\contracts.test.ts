// Contracts are the other money path: funded work binds real coin at posting, unfunded work
// is a promise, and a promise the client cannot keep becomes a debt note instead of an error.
// These tests weigh heaviest on the seal (nothing altered after the fact) and on coin
// conservation (nothing paid out or refunded that was not bound at posting).

import { describe, expect, it } from "vitest";
import {
  acceptContract,
  expireContract,
  isTerminal,
  markDelivered,
  postContract,
  rejectDelivery,
  settleContract,
  validateDraft,
  verifyContract,
  verifyDebtNote,
  verifyTerms,
  withdrawContract,
  reviewWindowElapsed,
  REVIEW_WINDOW_MS,
  type Contract,
  type ContractDraft,
  type DebtNote,
  type Outcome,
  type Party,
} from "../server/contracts/contract.ts";

const SECRET = "test-secret-not-a-real-key";
const NOW = 1_700_000_000_000;
const ONE_HOUR_MS = 60 * 60 * 1000;
// Mirrors the module's private minimum. It is not exported, so this is the one place that
// number lives on the test side; the "under five minutes throws" validateDraft test below
// uses the same constant, so if the real minimum ever drifts, that test catches it too.
const MIN_DURATION_MS = 5 * 60 * 1000;
const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

// Players, named like the server they're for.
const CLIENT: Party = { formId: 0xff000101, name: "Lucan Valerius" };
const WORKER: Party = { formId: 0xff000202, name: "Ysolda" };
const STRANGER: Party = { formId: 0xff000303, name: "Adrianne Avenicci" };

// Reward and escrow are always plain septim counts, never itemised, so vanilla gold (form
// 0x0000000F) never shows up here as a form id. Iron Ingot is the one item this module
// actually touches, through the deliverable on a goods contract.
const IRON_INGOT_FORM_ID = 0x0005ace4;

function baseDraftInput(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    kind: "goods",
    title: "Iron ingots for the forge",
    body: "Ten iron ingots, delivered to the smithy in Whiterun.",
    funding: "funded",
    reward: 200,
    deliverable: { formId: IRON_INGOT_FORM_ID, count: 10, label: "Iron Ingot" },
    durationMs: ONE_HOUR_MS,
    ...overrides,
  };
}

function fundedGoodsDraft(overrides: Record<string, unknown> = {}): ContractDraft {
  return validateDraft(baseDraftInput(overrides));
}

function unfundedServiceDraft(overrides: Record<string, unknown> = {}): ContractDraft {
  return validateDraft(
    baseDraftInput({
      kind: "service",
      title: "Escort to Riften",
      body: "Escort the client safely from Whiterun to Riften.",
      funding: "unfunded",
      reward: 150,
      ...overrides,
    }),
  );
}

function postFunded(id = "contract-0001", overrides: Record<string, unknown> = {}): Contract {
  const draft = fundedGoodsDraft(overrides);
  // A funded contract binds its full reward as escrow at the moment of posting.
  return postContract(draft, CLIENT, id, NOW, draft.reward, SECRET);
}

function postUnfunded(id = "contract-0002", overrides: Record<string, unknown> = {}): Contract {
  const draft = unfundedServiceDraft(overrides);
  // Unfunded contracts take no escrow. Nothing is bound, which is the entire risk the
  // worker takes by accepting one.
  return postContract(draft, CLIENT, id, NOW, 0, SECRET);
}

function acceptAndDeliver(posted: Contract): Contract {
  const accepted = acceptContract(posted, WORKER, NOW + 1000, SECRET);
  if (!accepted.ok) throw new Error("test setup failed: could not accept the contract");
  const delivered = markDelivered(accepted.contract, WORKER.formId, NOW + 2000, SECRET);
  if (!delivered.ok) throw new Error("test setup failed: could not mark the contract delivered");
  return delivered.contract;
}

function expectDebt(outcome: Outcome): DebtNote {
  if (!outcome.debt) throw new Error("expected the outcome to include a debt note");
  return outcome.debt;
}

function defaultedDebt(): DebtNote {
  const delivered = acceptAndDeliver(postUnfunded());
  const outcome = settleContract(delivered, NOW + 3000, 50, "debt-0001", SECRET);
  return expectDebt(outcome);
}

describe("posting and sealing", () => {
  it("a posted contract verifies", () => {
    const posted = postFunded();
    expect(verifyTerms(posted, SECRET)).toBe(true);
    expect(verifyContract(posted, SECRET)).toBe(true);
  });

  it("an unfunded contract posts with zero escrow bound", () => {
    const posted = postUnfunded();
    expect(posted.escrow).toBe(0);
    expect(posted.funding).toBe("unfunded");
  });

  it("a different secret does not verify", () => {
    const posted = postFunded();
    expect(verifyTerms(posted, "some-other-key")).toBe(false);
    expect(verifyContract(posted, "some-other-key")).toBe(false);
  });
});

describe("tampering with the terms breaks verifyTerms and verifyContract", () => {
  // Terms are what was AGREED: title, body, reward, deadline, who is buying, what's owed. If
  // any of it moved after posting, the contract is no longer what it claims to be, so both
  // checks must fail together.
  it("editing the title", () => {
    const forged: Contract = { ...postFunded(), title: "Something else entirely" };
    expect(verifyTerms(forged, SECRET)).toBe(false);
    expect(verifyContract(forged, SECRET)).toBe(false);
  });

  it("editing the body", () => {
    const forged: Contract = { ...postFunded(), body: "Something else entirely." };
    expect(verifyTerms(forged, SECRET)).toBe(false);
    expect(verifyContract(forged, SECRET)).toBe(false);
  });

  it("editing the reward", () => {
    const posted = postFunded();
    const forged: Contract = { ...posted, reward: posted.reward + 1 };
    expect(verifyTerms(forged, SECRET)).toBe(false);
    expect(verifyContract(forged, SECRET)).toBe(false);
  });

  it("editing the deadline", () => {
    const posted = postFunded();
    const forged: Contract = { ...posted, deadline: posted.deadline + 1000 };
    expect(verifyTerms(forged, SECRET)).toBe(false);
    expect(verifyContract(forged, SECRET)).toBe(false);
  });

  it("editing the client", () => {
    const forged: Contract = { ...postFunded(), client: STRANGER };
    expect(verifyTerms(forged, SECRET)).toBe(false);
    expect(verifyContract(forged, SECRET)).toBe(false);
  });

  it("editing the deliverable", () => {
    const posted = postFunded();
    const forged: Contract = { ...posted, deliverable: { ...posted.deliverable!, count: 9999 } };
    expect(verifyTerms(forged, SECRET)).toBe(false);
    expect(verifyContract(forged, SECRET)).toBe(false);
  });
});

describe("tampering after the terms breaks only verifyContract", () => {
  // This is the split the whole seal design rests on. The seal covers what HAPPENED (state,
  // worker, escrow, history) on top of the terms, so it can be forged without touching the
  // terms seal at all. verifyTerms proves what was agreed, and stays true here. Only
  // verifyContract is meant to catch this class of tampering.
  it("editing the state", () => {
    const forged: Contract = { ...postFunded(), state: "withdrawn" };
    expect(verifyTerms(forged, SECRET)).toBe(true);
    expect(verifyContract(forged, SECRET)).toBe(false);
  });

  it("editing the worker", () => {
    const forged: Contract = { ...postFunded(), worker: STRANGER };
    expect(verifyTerms(forged, SECRET)).toBe(true);
    expect(verifyContract(forged, SECRET)).toBe(false);
  });

  it("editing the escrow", () => {
    const posted = postFunded();
    const forged: Contract = { ...posted, escrow: posted.escrow + 1 };
    expect(verifyTerms(forged, SECRET)).toBe(true);
    expect(verifyContract(forged, SECRET)).toBe(false);
  });

  it("editing the history", () => {
    const posted = postFunded();
    const forged: Contract = {
      ...posted,
      history: [...posted.history, { at: NOW, state: "accepted", by: WORKER.formId }],
    };
    expect(verifyTerms(forged, SECRET)).toBe(true);
    expect(verifyContract(forged, SECRET)).toBe(false);
  });
});

describe("every transition refuses a tampered contract", () => {
  it("acceptContract", () => {
    const forged: Contract = { ...postFunded(), body: "A different job entirely." };
    const outcome = acceptContract(forged, WORKER, NOW + 1000, SECRET);
    expect(outcome.ok).toBe(false);
    expect(outcome.refusal).toBe("tampered");
  });

  it("withdrawContract", () => {
    const forged: Contract = { ...postFunded(), body: "A different job entirely." };
    const outcome = withdrawContract(forged, CLIENT.formId, SECRET);
    expect(outcome.ok).toBe(false);
    expect(outcome.refusal).toBe("tampered");
  });

  it("markDelivered", () => {
    const forged: Contract = { ...postFunded(), body: "A different job entirely." };
    const outcome = markDelivered(forged, WORKER.formId, NOW + 1000, SECRET);
    expect(outcome.ok).toBe(false);
    expect(outcome.refusal).toBe("tampered");
  });

  it("settleContract", () => {
    const forged: Contract = { ...postFunded(), body: "A different job entirely." };
    const outcome = settleContract(forged, NOW + 1000, 1000, "debt-x", SECRET);
    expect(outcome.ok).toBe(false);
    expect(outcome.refusal).toBe("tampered");
  });

  it("rejectDelivery", () => {
    const forged: Contract = { ...postFunded(), body: "A different job entirely." };
    const outcome = rejectDelivery(forged, CLIENT.formId, SECRET);
    expect(outcome.ok).toBe(false);
    expect(outcome.refusal).toBe("tampered");
  });

  it("expireContract", () => {
    const forged: Contract = { ...postFunded(), body: "A different job entirely." };
    const outcome = expireContract(forged, NOW + 1000, SECRET);
    expect(outcome.ok).toBe(false);
    expect(outcome.refusal).toBe("tampered");
  });
});

describe("debt notes seal too", () => {
  it("a debt note issued on default verifies", () => {
    const debt = defaultedDebt();
    expect(verifyDebtNote(debt, SECRET)).toBe(true);
  });

  it("editing the amount breaks the seal", () => {
    const debt = defaultedDebt();
    expect(verifyDebtNote({ ...debt, amount: debt.amount + 1 }, SECRET)).toBe(false);
  });

  it("editing the debtor breaks the seal", () => {
    const debt = defaultedDebt();
    expect(verifyDebtNote({ ...debt, debtor: STRANGER }, SECRET)).toBe(false);
  });

  it("editing the creditor breaks the seal", () => {
    const debt = defaultedDebt();
    expect(verifyDebtNote({ ...debt, creditor: STRANGER }, SECRET)).toBe(false);
  });

  it("editing the contract id breaks the seal", () => {
    const debt = defaultedDebt();
    expect(verifyDebtNote({ ...debt, contractId: "some-other-contract" }, SECRET)).toBe(false);
  });
});

describe("happy path: funded contract", () => {
  it("posts with the full reward bound as escrow", () => {
    const posted = postFunded();
    expect(posted.funding).toBe("funded");
    expect(posted.escrow).toBe(200);
    expect(posted.state).toBe("open");
  });

  it("runs open, accepted, delivered, settled, paying out exactly the escrow", () => {
    const posted = postFunded();
    const accepted = acceptContract(posted, WORKER, NOW + 1000, SECRET);
    expect(accepted.ok).toBe(true);
    expect(accepted.contract.state).toBe("accepted");
    expect(accepted.contract.worker).toEqual(WORKER);

    const delivered = markDelivered(accepted.contract, WORKER.formId, NOW + 2000, SECRET);
    expect(delivered.ok).toBe(true);
    expect(delivered.contract.state).toBe("delivered");

    // clientCoin is irrelevant here: a funded contract already bound its coin at posting.
    const settled = settleContract(delivered.contract, NOW + 3000, 0, "debt-unused", SECRET);
    expect(settled.ok).toBe(true);
    expect(settled.contract.state).toBe("settled");
    expect(settled.payout).toBe(200);
    expect(settled.contract.escrow).toBe(0);
    expect(settled.debt).toBeUndefined();
  });
});

describe("happy path: unfunded contract, client can pay", () => {
  it("settles for the full reward and returns no debt", () => {
    const delivered = acceptAndDeliver(postUnfunded());
    const outcome = settleContract(delivered, NOW + 3000, 500, "debt-unused", SECRET);
    expect(outcome.ok).toBe(true);
    expect(outcome.contract.state).toBe("settled");
    expect(outcome.payout).toBe(150);
    expect(outcome.debt).toBeUndefined();
  });

  it("settles rather than defaults when the client holds exactly the reward (boundary)", () => {
    const delivered = acceptAndDeliver(postUnfunded());
    const outcome = settleContract(delivered, NOW + 3000, 150, "debt-unused", SECRET);
    expect(outcome.contract.state).toBe("settled");
    expect(outcome.payout).toBe(150);
    expect(outcome.debt).toBeUndefined();
  });
});

describe("happy path: unfunded contract, client cannot pay", () => {
  it("defaults, issuing a debt note for the shortfall", () => {
    const posted = postUnfunded();
    const delivered = acceptAndDeliver(posted);
    const outcome = settleContract(delivered, NOW + 3000, 50, "debt-0001", SECRET);
    expect(outcome.ok).toBe(true);
    expect(outcome.contract.state).toBe("defaulted");
    // They pay what they have. The debt note covers the rest.
    expect(outcome.payout).toBe(50);

    const debt = expectDebt(outcome);
    expect(debt.amount).toBe(100);
    expect(debt.debtor).toEqual(CLIENT);
    expect(debt.creditor).toEqual(WORKER);
    expect(debt.contractId).toBe(posted.id);
    expect(verifyDebtNote(debt, SECRET)).toBe(true);
  });

  it("owes the full reward when the client holds nothing", () => {
    const delivered = acceptAndDeliver(postUnfunded());
    const outcome = settleContract(delivered, NOW + 3000, 0, "debt-0002", SECRET);
    expect(outcome.contract.state).toBe("defaulted");
    expect(outcome.payout).toBe(0);
    const debt = expectDebt(outcome);
    expect(debt.amount).toBe(150);
  });
});

describe("refusals", () => {
  it("accepting your own contract refuses client-cannot-take-own-contract", () => {
    const outcome = acceptContract(postFunded(), CLIENT, NOW + 1000, SECRET);
    expect(outcome.ok).toBe(false);
    expect(outcome.refusal).toBe("client-cannot-take-own-contract");
  });

  it("accepting something not open refuses not-open", () => {
    const accepted = acceptContract(postFunded(), WORKER, NOW + 1000, SECRET).contract;
    const outcome = acceptContract(accepted, STRANGER, NOW + 2000, SECRET);
    expect(outcome.refusal).toBe("not-open");
  });

  it("accepting past the deadline refuses past-deadline", () => {
    const posted = postFunded("contract-short", { durationMs: MIN_DURATION_MS });
    const outcome = acceptContract(posted, WORKER, posted.deadline, SECRET);
    expect(outcome.refusal).toBe("past-deadline");
  });

  it("withdrawing when accepted refuses not-open", () => {
    const accepted = acceptContract(postFunded(), WORKER, NOW + 1000, SECRET).contract;
    const outcome = withdrawContract(accepted, CLIENT.formId, SECRET);
    expect(outcome.refusal).toBe("not-open");
  });

  it("withdrawing as somebody other than the client refuses not-the-client", () => {
    const outcome = withdrawContract(postFunded(), STRANGER.formId, SECRET);
    expect(outcome.refusal).toBe("not-the-client");
  });

  it("delivering as somebody other than the worker refuses not-the-worker", () => {
    const accepted = acceptContract(postFunded(), WORKER, NOW + 1000, SECRET).contract;
    const outcome = markDelivered(accepted, STRANGER.formId, NOW + 2000, SECRET);
    expect(outcome.refusal).toBe("not-the-worker");
  });

  it("delivering something not accepted refuses not-accepted", () => {
    const outcome = markDelivered(postFunded(), WORKER.formId, NOW + 1000, SECRET);
    expect(outcome.refusal).toBe("not-accepted");
  });

  it("delivering past the deadline refuses past-deadline", () => {
    const posted = postFunded("contract-short", { durationMs: MIN_DURATION_MS });
    const accepted = acceptContract(posted, WORKER, NOW + 1000, SECRET).contract;
    const outcome = markDelivered(accepted, WORKER.formId, posted.deadline, SECRET);
    expect(outcome.refusal).toBe("past-deadline");
  });

  it("settling something not delivered refuses not-delivered", () => {
    const outcome = settleContract(postFunded(), NOW + 1000, 0, "debt-x", SECRET);
    expect(outcome.refusal).toBe("not-delivered");
  });

  it("rejecting as somebody other than the client refuses not-the-client", () => {
    const delivered = acceptAndDeliver(postFunded());
    const outcome = rejectDelivery(delivered, STRANGER.formId, SECRET);
    expect(outcome.refusal).toBe("not-the-client");
  });

  it("expiring before the deadline refuses past-deadline", () => {
    const outcome = expireContract(postFunded(), NOW, SECRET);
    expect(outcome.refusal).toBe("past-deadline");
  });

  it("every transition on a terminal contract refuses already-terminal", () => {
    const withdrawn = withdrawContract(postFunded(), CLIENT.formId, SECRET).contract;

    expect(acceptContract(withdrawn, WORKER, NOW + 1000, SECRET).refusal).toBe("already-terminal");
    expect(withdrawContract(withdrawn, CLIENT.formId, SECRET).refusal).toBe("already-terminal");
    expect(markDelivered(withdrawn, WORKER.formId, NOW + 1000, SECRET).refusal).toBe("already-terminal");
    expect(settleContract(withdrawn, NOW + 1000, 1000, "debt-x", SECRET).refusal).toBe("already-terminal");
    expect(rejectDelivery(withdrawn, CLIENT.formId, SECRET).refusal).toBe("already-terminal");
    expect(expireContract(withdrawn, NOW + 999_999_999, SECRET).refusal).toBe("already-terminal");
  });
});

describe("money movement", () => {
  it("withdraw refunds the full escrow and zeroes contract.escrow", () => {
    const outcome = withdrawContract(postFunded(), CLIENT.formId, SECRET);
    expect(outcome.refund).toBe(200);
    expect(outcome.contract.escrow).toBe(0);
  });

  it("reject refunds the full escrow", () => {
    const delivered = acceptAndDeliver(postFunded());
    const outcome = rejectDelivery(delivered, CLIENT.formId, SECRET);
    expect(outcome.refund).toBe(200);
    expect(outcome.contract.escrow).toBe(0);
  });

  it("expire refunds the full escrow from an open contract", () => {
    const posted = postFunded("contract-short", { durationMs: MIN_DURATION_MS });
    const outcome = expireContract(posted, posted.deadline, SECRET);
    expect(outcome.refund).toBe(200);
    expect(outcome.contract.escrow).toBe(0);
    expect(outcome.contract.state).toBe("expired");
  });

  it("expire refunds the full escrow from an accepted contract", () => {
    const posted = postFunded("contract-short", { durationMs: MIN_DURATION_MS });
    const accepted = acceptContract(posted, WORKER, NOW + 1000, SECRET).contract;
    const outcome = expireContract(accepted, posted.deadline, SECRET);
    expect(outcome.refund).toBe(200);
    expect(outcome.contract.escrow).toBe(0);
    expect(outcome.contract.state).toBe("expired");
  });

  it("a funded settle pays out the escrow and zeroes it", () => {
    const delivered = acceptAndDeliver(postFunded());
    const outcome = settleContract(delivered, NOW + 3000, 0, "debt-unused", SECRET);
    expect(outcome.payout).toBe(200);
    expect(outcome.contract.escrow).toBe(0);
  });
});

describe("coin conservation, the invariant that matters most", () => {
  // Every terminal path on a funded contract must move exactly the coin bound at posting:
  // never more (that would print coin out of nowhere) and never less (that would burn it).
  const ESCROW = 200;

  it("settle pays out exactly the escrow, refunding nothing", () => {
    const delivered = acceptAndDeliver(postFunded());
    const outcome = settleContract(delivered, NOW + 3000, 0, "debt-unused", SECRET);
    expect((outcome.payout ?? 0) + (outcome.refund ?? 0)).toBe(ESCROW);
  });

  it("withdraw refunds exactly the escrow, paying out nothing", () => {
    const outcome = withdrawContract(postFunded(), CLIENT.formId, SECRET);
    expect((outcome.payout ?? 0) + (outcome.refund ?? 0)).toBe(ESCROW);
  });

  it("reject refunds exactly the escrow, paying out nothing", () => {
    const delivered = acceptAndDeliver(postFunded());
    const outcome = rejectDelivery(delivered, CLIENT.formId, SECRET);
    expect((outcome.payout ?? 0) + (outcome.refund ?? 0)).toBe(ESCROW);
  });

  it("expire from open refunds exactly the escrow", () => {
    const posted = postFunded("contract-short", { durationMs: MIN_DURATION_MS });
    const outcome = expireContract(posted, posted.deadline, SECRET);
    expect((outcome.payout ?? 0) + (outcome.refund ?? 0)).toBe(ESCROW);
  });

  it("expire from accepted refunds exactly the escrow", () => {
    const posted = postFunded("contract-short", { durationMs: MIN_DURATION_MS });
    const accepted = acceptContract(posted, WORKER, NOW + 1000, SECRET).contract;
    const outcome = expireContract(accepted, posted.deadline, SECRET);
    expect((outcome.payout ?? 0) + (outcome.refund ?? 0)).toBe(ESCROW);
  });
});

describe("immutability", () => {
  it("acceptContract does not mutate its input", () => {
    const posted = postFunded();
    const state = posted.state;
    const historyLength = posted.history.length;
    acceptContract(posted, WORKER, NOW + 1000, SECRET);
    expect(posted.state).toBe(state);
    expect(posted.history).toHaveLength(historyLength);
  });

  it("withdrawContract does not mutate its input", () => {
    const posted = postFunded();
    const state = posted.state;
    const historyLength = posted.history.length;
    withdrawContract(posted, CLIENT.formId, SECRET);
    expect(posted.state).toBe(state);
    expect(posted.history).toHaveLength(historyLength);
  });

  it("markDelivered does not mutate its input", () => {
    const accepted = acceptContract(postFunded(), WORKER, NOW + 1000, SECRET).contract;
    const state = accepted.state;
    const historyLength = accepted.history.length;
    markDelivered(accepted, WORKER.formId, NOW + 2000, SECRET);
    expect(accepted.state).toBe(state);
    expect(accepted.history).toHaveLength(historyLength);
  });

  it("settleContract does not mutate its input", () => {
    const delivered = acceptAndDeliver(postFunded());
    const state = delivered.state;
    const historyLength = delivered.history.length;
    settleContract(delivered, NOW + 3000, 0, "debt-unused", SECRET);
    expect(delivered.state).toBe(state);
    expect(delivered.history).toHaveLength(historyLength);
  });

  it("rejectDelivery does not mutate its input", () => {
    const delivered = acceptAndDeliver(postFunded());
    const state = delivered.state;
    const historyLength = delivered.history.length;
    rejectDelivery(delivered, CLIENT.formId, SECRET);
    expect(delivered.state).toBe(state);
    expect(delivered.history).toHaveLength(historyLength);
  });

  it("expireContract does not mutate its input", () => {
    const posted = postFunded("contract-short", { durationMs: MIN_DURATION_MS });
    const state = posted.state;
    const historyLength = posted.history.length;
    expireContract(posted, posted.deadline, SECRET);
    expect(posted.state).toBe(state);
    expect(posted.history).toHaveLength(historyLength);
  });
});

describe("isTerminal", () => {
  it("is true only for settled, rejected, expired, withdrawn and defaulted", () => {
    expect(isTerminal("settled")).toBe(true);
    expect(isTerminal("rejected")).toBe(true);
    expect(isTerminal("expired")).toBe(true);
    expect(isTerminal("withdrawn")).toBe(true);
    expect(isTerminal("defaulted")).toBe(true);
    expect(isTerminal("open")).toBe(false);
    expect(isTerminal("accepted")).toBe(false);
    expect(isTerminal("delivered")).toBe(false);
  });
});

describe("validateDraft treats input as hostile", () => {
  it("rejects a kind other than goods or service", () => {
    expect(() => validateDraft(baseDraftInput({ kind: "quest" }))).toThrow(/kind must be goods or service/);
  });

  it("rejects a funding other than funded or unfunded", () => {
    expect(() => validateDraft(baseDraftInput({ funding: "escrowed" }))).toThrow(
      /funding must be funded or unfunded/,
    );
  });

  it("a goods contract without a deliverable throws", () => {
    expect(() =>
      validateDraft({
        kind: "goods",
        title: "Iron ingots",
        body: "Ten iron ingots.",
        funding: "funded",
        reward: 200,
        durationMs: ONE_HOUR_MS,
      }),
    ).toThrow(/needs a deliverable/);
  });

  it("rejects a deliverable count of 0, and a negative or non-integer form id", () => {
    expect(() =>
      validateDraft(baseDraftInput({ deliverable: { formId: IRON_INGOT_FORM_ID, count: 0, label: "Iron Ingot" } })),
    ).toThrow(/count must be at least 1/);
    expect(() =>
      validateDraft(baseDraftInput({ deliverable: { formId: -1, count: 10, label: "Iron Ingot" } })),
    ).toThrow(/deliverable\.formId/);
    expect(() =>
      validateDraft(baseDraftInput({ deliverable: { formId: 1.5, count: 10, label: "Iron Ingot" } })),
    ).toThrow(/deliverable\.formId/);
  });

  it("rejects an empty or whitespace title, and an oversized body", () => {
    expect(() => validateDraft(baseDraftInput({ title: "" }))).toThrow(/cannot be empty/);
    expect(() => validateDraft(baseDraftInput({ title: "   " }))).toThrow(/cannot be empty/);
    expect(() => validateDraft(baseDraftInput({ body: "x".repeat(1501) }))).toThrow(/longer than/);
  });

  it("rejects a negative or non-integer reward", () => {
    expect(() => validateDraft(baseDraftInput({ reward: -5 }))).toThrow(/reward must be a whole number/);
    expect(() => validateDraft(baseDraftInput({ reward: 10.5 }))).toThrow(/reward must be a whole number/);
  });

  it("rejects a duration under five minutes, and over thirty days", () => {
    expect(() => validateDraft(baseDraftInput({ durationMs: MIN_DURATION_MS - 1 }))).toThrow(
      /at least five minutes/,
    );
    expect(() => validateDraft(baseDraftInput({ durationMs: THIRTY_DAYS_MS + 1 }))).toThrow(/durationMs/);
  });

  it("strips control characters out of the title and body", () => {
    const d = validateDraft(
      baseDraftInput({ title: "Iron ingots\u0000 for the forge", body: "Bring them by dusk\u001b[31m." }),
    );
    expect(d.title).toBe("Iron ingots for the forge");
    expect(d.body).not.toContain("\u001b");
    expect(d.body).toBe("Bring them by dusk[31m.");
  });

  it("keeps newlines in the body, because a contract body legitimately has them", () => {
    const d = validateDraft(baseDraftInput({ body: "Ten iron ingots.\nDeliver to the smithy by dusk." }));
    expect(d.body).toContain("\n");
  });
});

describe("history", () => {
  it("grows by exactly one entry per transition, with the right state and by", () => {
    const posted = postFunded();
    expect(posted.history).toHaveLength(1);
    expect(posted.history[0]).toMatchObject({ state: "posted", by: CLIENT.formId });

    const accepted = acceptContract(posted, WORKER, NOW + 1000, SECRET).contract;
    expect(accepted.history).toHaveLength(2);
    expect(accepted.history.at(-1)).toMatchObject({ state: "accepted", by: WORKER.formId });

    const delivered = markDelivered(accepted, WORKER.formId, NOW + 2000, SECRET).contract;
    expect(delivered.history).toHaveLength(3);
    expect(delivered.history.at(-1)).toMatchObject({ state: "delivered", by: WORKER.formId });

    const settled = settleContract(delivered, NOW + 3000, 0, "debt-unused", SECRET).contract;
    expect(settled.history).toHaveLength(4);
    expect(settled.history.at(-1)).toMatchObject({ state: "settled", by: null });
  });
});

// ---------------------------------------------------------------------------
// Finalisation, which is where both sides can cheat each other.
//
// A funded contract holds real coin between the moment work is claimed done and the moment it
// is paid for. Whoever gets to end that standoff unilaterally can rob the other one, so these
// pin down who may, and when.
// ---------------------------------------------------------------------------

describe("who gets to say the work is finished", () => {
  const client: Party = { formId: 0xff000001, name: "Aldric Vane" };
  const worker: Party = { formId: 0xff000002, name: "Brynjar Stone-Hand" };

  function fundedService(): Contract {
    const draft = validateDraft({
      kind: "service",
      funding: "funded",
      title: "Clear the bandits from Halted Stream",
      body: "Quietly.",
      reward: 500,
      durationMs: ONE_HOUR_MS,
    });
    const posted = postContract(draft, client, "con-fin", NOW, 500, SECRET);
    const taken = acceptContract(posted, worker, NOW, SECRET);
    return taken.contract;
  }

  it("does not pay a funded service the instant the worker claims it done", () => {
    // Otherwise anyone takes a funded job, says "done", and walks off with the escrow.
    const delivered = markDelivered(fundedService(), worker.formId, NOW, SECRET);
    expect(delivered.ok).toBe(true);
    expect(delivered.contract.state).toBe("delivered");
    expect(delivered.contract.escrow).toBe(500);
    expect(delivered.payout).toBeUndefined();
  });

  it("will not expire delivered work, which is how a silent client steals it back", () => {
    const delivered = markDelivered(fundedService(), worker.formId, NOW, SECRET).contract;
    const expired = expireContract(delivered, NOW + ONE_HOUR_MS * 2, SECRET);
    expect(expired.ok).toBe(false);
    expect(expired.refusal).toBe("awaiting-settlement");
    expect(expired.contract.escrow).toBe(500);
  });

  it("holds the escrow while the client still has time to look", () => {
    const delivered = markDelivered(fundedService(), worker.formId, NOW, SECRET).contract;
    expect(reviewWindowElapsed(delivered, NOW)).toBe(false);
    expect(reviewWindowElapsed(delivered, NOW + REVIEW_WINDOW_MS - 1)).toBe(false);
  });

  it("releases to the worker once the client has had their look and said nothing", () => {
    const delivered = markDelivered(fundedService(), worker.formId, NOW, SECRET).contract;
    const at = NOW + REVIEW_WINDOW_MS;
    expect(reviewWindowElapsed(delivered, at)).toBe(true);

    const settled = settleContract(delivered, at, 0, "debt-x", SECRET);
    expect(settled.ok).toBe(true);
    expect(settled.contract.state).toBe("settled");
    expect(settled.payout).toBe(500);
  });

  it("still lets the client refuse inside the window, and returns the coin", () => {
    const delivered = markDelivered(fundedService(), worker.formId, NOW, SECRET).contract;
    const refused = rejectDelivery(delivered, client.formId, SECRET);
    expect(refused.ok).toBe(true);
    expect(refused.contract.state).toBe("rejected");
    expect(refused.refund).toBe(500);
  });

  it("never lets the worker refuse their own delivery", () => {
    const delivered = markDelivered(fundedService(), worker.formId, NOW, SECRET).contract;
    expect(rejectDelivery(delivered, worker.formId, SECRET).ok).toBe(false);
  });
});
