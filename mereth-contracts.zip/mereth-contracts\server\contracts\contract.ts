// Player-to-player contracts.
//
// The design question that shapes everything: what happens when somebody does not hold up
// their end? The answer here is deliberately NOT arbitration. This module records what
// happened and refuses to decide who was right. No court, no staff queue, no dispute
// ticket. The social layer does what social layers are for.
//
// Two ideas carry the weight:
//
//   1. A contract is FUNDED or UNFUNDED, and everybody can see which. Funded binds the coin
//      at posting, so the worker is certain of payment. Unfunded is a promise, and a worker
//      taking one is betting on the client's word. That single visible flag turns
//      reputation from a number into "will people work for you on your word alone".
//
//   2. An unfunded contract the client cannot pay does not error. It becomes a DEBT NOTE:
//      sealed, naming both parties, pointing at the contract it came from, and readable by
//      anyone. A broken promise becomes an object in the world rather than a failure state.
//
// Nothing here touches `mp`, so it is fully testable headless. Escrow movement lives in
// escrow.ts, wiring in service.ts.

import { createHmac, timingSafeEqual } from "node:crypto";
import { canonicalize, type Canonical } from "../canonical";

export const CONTRACT_VERSION = 1;

export type ContractKind = "goods" | "service";
export type Funding = "funded" | "unfunded";

export type ContractState =
  /** Posted, nobody has taken it. */
  | "open"
  /** A worker has taken it exclusively. The clock is running. */
  | "accepted"
  /** The worker says it is done. Goods contracts reach this only after a verified transfer. */
  | "delivered"
  /** Paid. Terminal. */
  | "settled"
  /** The client refused the delivery. Escrow returned. Recorded against BOTH parties. */
  | "rejected"
  /** Deadline passed. Escrow returned. */
  | "expired"
  /** The client pulled it before anyone took it. */
  | "withdrawn"
  /** Delivered, unfunded, and the client could not pay. A debt note exists. Terminal. */
  | "defaulted";

const TERMINAL: ReadonlySet<ContractState> = new Set<ContractState>([
  "settled",
  "rejected",
  "expired",
  "withdrawn",
  "defaulted",
]);

/**
 * A party to a contract, identified by character rather than by account.
 *
 * `actorId` is the same number as the form id and is stated separately so that anything
 * reading a stored contract can see what it is bound to without knowing the convention.
 */
export interface Party {
  formId: number;
  actorId: number;
  name: string;
}

/** What the worker must hand over. Goods only: services are not mechanically verifiable. */
export interface Deliverable {
  formId: number;
  count: number;
  label: string;
}

export interface ContractEvent {
  at: number;
  state: ContractState | "posted";
  by: number | null;
  note?: string;
}

export interface Contract {
  version: number;
  id: string;
  kind: ContractKind;
  title: string;
  body: string;
  client: Party;
  worker: Party | null;
  /** Septims promised. */
  reward: number;
  funding: Funding;
  /** Coin actually bound to this contract. Zero on an unfunded one. */
  escrow: number;
  deliverable: Deliverable | null;
  /** The hold whose board carries this, or null for one posted nowhere in particular. */
  hold: string | null;
  postedAt: number;
  deadline: number;
  state: ContractState;
  history: ContractEvent[];
  /** Seals the TERMS, which never change. Proves what was agreed. */
  termsSeal: string;
  /** Seals the whole record including state and history. Recomputed on every transition. */
  seal: string;
}

export interface DebtNote {
  version: number;
  id: string;
  contractId: string;
  debtor: Party;
  creditor: Party;
  amount: number;
  incurredAt: number;
  seal: string;
}

const MAX_TITLE = 100;
const MAX_BODY = 1500;
const MAX_REWARD = 1_000_000;
const MAX_COUNT = 10_000;
/** Control characters, keeping tab and newline. A body legitimately has line breaks. */
const CONTROL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

function hmac(secret: string, payload: string): string {
  return createHmac("sha256", secret).update(payload, "utf8").digest("hex");
}

function sealsMatch(a: string, b: string): boolean {
  const left = Buffer.from(a, "utf8");
  const right = Buffer.from(b, "utf8");
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

function party(p: Party): Canonical {
  // actorId is inside the seal on purpose. It is what the contract is bound to, so a record
  // whose party was swapped for another character has to fail verification.
  return { formId: p.formId, actorId: p.actorId, name: p.name };
}

/** The immutable agreement. Deliberately excludes state, worker and history. */
function terms(c: Contract): Canonical {
  return {
    version: c.version,
    id: c.id,
    hold: c.hold,
    kind: c.kind,
    title: c.title,
    body: c.body,
    client: party(c.client),
    reward: c.reward,
    funding: c.funding,
    deliverable: c.deliverable
      ? { formId: c.deliverable.formId, count: c.deliverable.count, label: c.deliverable.label }
      : null,
    postedAt: c.postedAt,
    deadline: c.deadline,
  };
}

function whole(c: Contract): Canonical {
  return {
    terms: terms(c),
    termsSeal: c.termsSeal,
    worker: c.worker ? party(c.worker) : null,
    escrow: c.escrow,
    state: c.state,
    history: c.history.map((e) => ({
      at: e.at,
      state: e.state,
      by: e.by,
      ...(e.note === undefined ? {} : { note: e.note }),
    })),
  };
}

/** Recompute both seals. Every transition goes through here, so a record is never unsealed. */
function reseal(c: Contract, secret: string): Contract {
  const withTerms = { ...c, termsSeal: hmac(secret, canonicalize(terms(c))) };
  return { ...withTerms, seal: hmac(secret, canonicalize(whole(withTerms))) };
}

/** True when the terms are exactly what was agreed, regardless of what has happened since. */
export function verifyTerms(c: Contract, secret: string): boolean {
  return sealsMatch(c.termsSeal, hmac(secret, canonicalize(terms(c))));
}

/** True when nothing in the record has been altered, including its state and history. */
export function verifyContract(c: Contract, secret: string): boolean {
  if (!verifyTerms(c, secret)) return false;
  return sealsMatch(c.seal, hmac(secret, canonicalize(whole(c))));
}

export function verifyDebtNote(note: DebtNote, secret: string): boolean {
  const payload = canonicalize({
    version: note.version,
    id: note.id,
    contractId: note.contractId,
    debtor: party(note.debtor),
    creditor: party(note.creditor),
    amount: note.amount,
    incurredAt: note.incurredAt,
  });
  return sealsMatch(note.seal, hmac(secret, payload));
}

// ---------------------------------------------------------------------------
// Validation. Everything below treats its input as hostile.
// ---------------------------------------------------------------------------

function cleanText(value: unknown, field: string, max: number): string {
  if (typeof value !== "string") throw new Error(`${field} must be a string`);
  const stripped = value.replace(CONTROL, "").trim();
  if (stripped === "") throw new Error(`${field} cannot be empty`);
  if (stripped.length > max) throw new Error(`${field} is longer than ${max} characters`);
  return stripped;
}

function wholeNumber(value: unknown, field: string, max: number): number {
  if (typeof value !== "number" || !Number.isInteger(value) || value < 0 || value > max) {
    throw new Error(`${field} must be a whole number between 0 and ${max}`);
  }
  return value;
}

export interface ContractDraft {
  kind: ContractKind;
  title: string;
  body: string;
  reward: number;
  funding: Funding;
  deliverable: Deliverable | null;
  /** Milliseconds from posting until the contract lapses. */
  durationMs: number;
  /**
   * The hold this contract belongs to, which is the board it was pinned at.
   *
   * Contracts are local. A job in Falkreath has no business appearing on a board in Windhelm,
   * and making that the poster's problem rather than the reader's is what keeps a board worth
   * walking to. Optional so a caller that has not wired boards up yet still compiles.
   */
  hold?: string | null;
}

/**
 * How long a client has to look at delivered work before the escrow releases itself.
 *
 * This exists because both sides can otherwise cheat. Without a release, a client simply
 * ignores finished work until the deadline and takes their coin back. Without a window, a
 * worker takes a funded job, claims it done immediately, and walks off with the escrow. The
 * window gives the client a real chance to refuse and guarantees the worker gets paid if they
 * do not use it.
 */
export const REVIEW_WINDOW_MS = 48 * 60 * 60 * 1000;

const MAX_HOLD = 48;
const MIN_DURATION_MS = 5 * 60 * 1000;
const MAX_DURATION_MS = 30 * 24 * 60 * 60 * 1000;

export function validateDraft(input: unknown): ContractDraft {
  if (typeof input !== "object" || input === null) throw new Error("draft must be an object");
  const raw = input as Record<string, unknown>;

  const kind = raw["kind"];
  if (kind !== "goods" && kind !== "service") throw new Error("kind must be goods or service");

  const funding = raw["funding"];
  if (funding !== "funded" && funding !== "unfunded") throw new Error("funding must be funded or unfunded");

  let deliverable: Deliverable | null = null;
  if (kind === "goods") {
    const d = raw["deliverable"];
    if (typeof d !== "object" || d === null) throw new Error("a goods contract needs a deliverable");
    const dd = d as Record<string, unknown>;
    // A goods contract is only worth having because delivery is machine checkable, so the
    // form id and count are mandatory rather than decorative.
    deliverable = {
      formId: wholeNumber(dd["formId"], "deliverable.formId", 0xffffffff),
      count: wholeNumber(dd["count"], "deliverable.count", MAX_COUNT),
      label: cleanText(dd["label"], "deliverable.label", 80),
    };
    if (deliverable.count < 1) throw new Error("deliverable.count must be at least 1");
  }

  const durationMs = wholeNumber(raw["durationMs"], "durationMs", MAX_DURATION_MS);
  if (durationMs < MIN_DURATION_MS) throw new Error("durationMs must be at least five minutes");

  // The hold is whichever board this was pinned at. It is optional so a caller that has not
  // wired boards up yet still works, and it is length capped and trimmed like any other
  // string arriving from a client.
  const rawHold = raw["hold"];
  const hold = rawHold === undefined || rawHold === null
    ? null
    : cleanText(rawHold, "hold", MAX_HOLD);

  return {
    kind,
    funding,
    deliverable,
    hold,
    title: cleanText(raw["title"], "title", MAX_TITLE),
    body: cleanText(raw["body"], "body", MAX_BODY),
    reward: wholeNumber(raw["reward"], "reward", MAX_REWARD),
    durationMs,
  };
}

// ---------------------------------------------------------------------------
// Transitions. Each returns a NEW contract and never mutates its input.
// ---------------------------------------------------------------------------

export type Refusal =
  | "not-open"
  | "not-accepted"
  | "not-delivered"
  | "not-the-client"
  | "not-the-worker"
  | "client-cannot-take-own-contract"
  | "past-deadline"
  | "already-terminal"
  | "awaiting-settlement"
  | "tampered";

export interface Outcome {
  ok: boolean;
  refusal?: Refusal;
  contract: Contract;
  /** Present only when an unfunded contract settled into a debt. */
  debt?: DebtNote;
  /** Coin the caller must actually move. Positive means pay this to the worker. */
  payout?: number;
  /** Coin the caller must return to the client. */
  refund?: number;
}

/**
 * Append a history entry stamped with the caller's clock, not the wall clock.
 *
 * Every transition that matters takes `now` so the module stays pure and testable, and the
 * history has to agree with it. Reading Date.now() here instead silently put real wall-clock
 * timestamps into records the rest of the module reasons about with an injected clock, which
 * broke anything measuring from a history entry. The review window measures from exactly one.
 */
function push(
  c: Contract,
  state: ContractState,
  by: number | null,
  at: number,
  note?: string,
): ContractEvent[] {
  return [...c.history, { at, state, by, ...(note === undefined ? {} : { note }) }];
}

export function postContract(
  draft: ContractDraft,
  client: Party,
  id: string,
  now: number,
  escrowTaken: number,
  secret: string,
): Contract {
  const base: Contract = {
    version: CONTRACT_VERSION,
    id,
    kind: draft.kind,
    title: draft.title,
    body: draft.body,
    client,
    worker: null,
    reward: draft.reward,
    funding: draft.funding,
    escrow: escrowTaken,
    deliverable: draft.deliverable,
    // A draft built in code rather than validated may omit this, and a contract with an
    // undefined field would fail to canonicalise, so it is normalised here.
    hold: draft.hold ?? null,
    postedAt: now,
    deadline: now + draft.durationMs,
    state: "open",
    history: [{ at: now, state: "posted", by: client.formId }],
    termsSeal: "",
    seal: "",
  };
  return reseal(base, secret);
}

export function acceptContract(c: Contract, worker: Party, now: number, secret: string): Outcome {
  if (!verifyContract(c, secret)) return { ok: false, refusal: "tampered", contract: c };
  if (TERMINAL.has(c.state)) return { ok: false, refusal: "already-terminal", contract: c };
  if (c.state !== "open") return { ok: false, refusal: "not-open", contract: c };
  // Taking your own contract would let a client launder coin through escrow into their own
  // pocket while manufacturing a completion record.
  if (worker.formId === c.client.formId) {
    return { ok: false, refusal: "client-cannot-take-own-contract", contract: c };
  }
  if (now >= c.deadline) return { ok: false, refusal: "past-deadline", contract: c };

  const next = reseal(
    { ...c, worker, state: "accepted", history: push(c, "accepted", worker.formId, now) },
    secret,
  );
  return { ok: true, contract: next };
}

export function withdrawContract(c: Contract, by: number, secret: string): Outcome {
  if (!verifyContract(c, secret)) return { ok: false, refusal: "tampered", contract: c };
  if (TERMINAL.has(c.state)) return { ok: false, refusal: "already-terminal", contract: c };
  // Only while nobody has taken it. Once a worker has committed time, the client cannot
  // simply pull the job out from under them.
  if (c.state !== "open") return { ok: false, refusal: "not-open", contract: c };
  if (by !== c.client.formId) return { ok: false, refusal: "not-the-client", contract: c };

  const next = reseal({ ...c, state: "withdrawn", escrow: 0, history: push(c, "withdrawn", by, Date.now()) }, secret);
  return { ok: true, contract: next, refund: c.escrow };
}

/** Called only once the service layer has verified the goods actually moved. */
export function markDelivered(c: Contract, by: number, now: number, secret: string): Outcome {
  if (!verifyContract(c, secret)) return { ok: false, refusal: "tampered", contract: c };
  if (TERMINAL.has(c.state)) return { ok: false, refusal: "already-terminal", contract: c };
  if (c.state !== "accepted") return { ok: false, refusal: "not-accepted", contract: c };
  if (c.worker === null || by !== c.worker.formId) return { ok: false, refusal: "not-the-worker", contract: c };
  if (now >= c.deadline) return { ok: false, refusal: "past-deadline", contract: c };

  const next = reseal({ ...c, state: "delivered", history: push(c, "delivered", by, now) }, secret);
  return { ok: true, contract: next };
}

/**
 * Settle a delivered contract.
 *
 * `clientCoin` is what the client actually holds right now, and matters only for an
 * unfunded contract: a funded one already bound the coin at posting and cannot fail here.
 * That asymmetry is the whole point of the funded flag.
 */
export function settleContract(
  c: Contract,
  now: number,
  clientCoin: number,
  debtId: string,
  secret: string,
): Outcome {
  if (!verifyContract(c, secret)) return { ok: false, refusal: "tampered", contract: c };
  if (TERMINAL.has(c.state)) return { ok: false, refusal: "already-terminal", contract: c };
  if (c.state !== "delivered") return { ok: false, refusal: "not-delivered", contract: c };
  if (c.worker === null) return { ok: false, refusal: "not-the-worker", contract: c };

  if (c.funding === "funded") {
    const next = reseal({ ...c, state: "settled", escrow: 0, history: push(c, "settled", null, now) }, secret);
    return { ok: true, contract: next, payout: c.escrow };
  }

  if (clientCoin >= c.reward) {
    const next = reseal({ ...c, state: "settled", history: push(c, "settled", c.client.formId, now) }, secret);
    return { ok: true, contract: next, payout: c.reward };
  }

  // The interesting path. A promise the client cannot keep becomes an object in the world.
  const shortfall = c.reward - clientCoin;
  const note: DebtNote = {
    version: CONTRACT_VERSION,
    id: debtId,
    contractId: c.id,
    debtor: c.client,
    creditor: c.worker,
    amount: shortfall,
    incurredAt: now,
    seal: "",
  };
  const sealed: DebtNote = {
    ...note,
    seal: hmac(
      secret,
      canonicalize({
        version: note.version,
        id: note.id,
        contractId: note.contractId,
        debtor: party(note.debtor),
        creditor: party(note.creditor),
        amount: note.amount,
        incurredAt: note.incurredAt,
      }),
    ),
  };
  const next = reseal(
    {
      ...c,
      state: "defaulted",
      history: push(c, "defaulted", c.client.formId, now, `owes ${shortfall}`),
    },
    secret,
  );
  return { ok: true, contract: next, debt: sealed, payout: clientCoin };
}

/** The client refuses the delivery. Recorded against BOTH parties, and judged by neither. */
export function rejectDelivery(c: Contract, by: number, secret: string): Outcome {
  if (!verifyContract(c, secret)) return { ok: false, refusal: "tampered", contract: c };
  if (TERMINAL.has(c.state)) return { ok: false, refusal: "already-terminal", contract: c };
  if (c.state !== "delivered") return { ok: false, refusal: "not-delivered", contract: c };
  if (by !== c.client.formId) return { ok: false, refusal: "not-the-client", contract: c };

  const next = reseal({ ...c, state: "rejected", escrow: 0, history: push(c, "rejected", by, Date.now()) }, secret);
  return { ok: true, contract: next, refund: c.escrow };
}

/** Deadline swept. Refunds escrow, and records a non-completion against a worker who took it. */
export function expireContract(c: Contract, now: number, secret: string): Outcome {
  if (!verifyContract(c, secret)) return { ok: false, refusal: "tampered", contract: c };
  if (TERMINAL.has(c.state)) return { ok: false, refusal: "already-terminal", contract: c };
  // Delivered work is waiting on the client, not on the worker. Expiring it here would hand
  // the escrow back for a job that was actually done, which is a client stiffing a worker by
  // doing nothing at all. It releases through the review window instead.
  if (c.state === "delivered") return { ok: false, refusal: "awaiting-settlement", contract: c };
  if (now < c.deadline) return { ok: false, refusal: "past-deadline", contract: c };

  const note = c.state === "accepted" ? "accepted but not delivered" : "nobody took it";
  const next = reseal({ ...c, state: "expired", escrow: 0, history: push(c, "expired", null, now, note) }, secret);
  return { ok: true, contract: next, refund: c.escrow };
}

/** When the worker reported the job done, or null if they have not. */
export function deliveredAt(c: Contract): number | null {
  for (let i = c.history.length - 1; i >= 0; i -= 1) {
    const event = c.history[i];
    if (event !== undefined && event.state === "delivered") return event.at;
  }
  return null;
}

/** True once the client has had their full look at delivered work and said nothing. */
export function reviewWindowElapsed(c: Contract, now: number): boolean {
  if (c.state !== "delivered") return false;
  const at = deliveredAt(c);
  return at !== null && now - at >= REVIEW_WINDOW_MS;
}

export function isTerminal(state: ContractState): boolean {
  return TERMINAL.has(state);
}
