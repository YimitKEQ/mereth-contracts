// The SkyMP server API, typed.
//
// `mp` is a global injected by skymp5-server. Declaring it inside a module gives us types
// without emitting anything, so the bundled gamemode still reads the real global at runtime.
//
// Signatures verified against a running server (skymp5-server CI build, 2026-07-31). Two of
// them differ from what the secondhand documentation implies, noted inline.

export interface MpPropertyOptions {
  isVisibleByOwner: boolean;
  isVisibleByNeighbors: boolean;
  updateOwner: string;
  updateNeighbor: string;
}

export interface MpApi {
  makeProperty(name: string, options: MpPropertyOptions): void;
  makeEventSource(eventName: string, functionBody: string): void;
  get(formId: number, propertyName: string): unknown;
  set(formId: number, propertyName: string, value: unknown): void;
  clear(): void;

  /** Spawns at Tamriel origin and returns the new form id. Position it afterwards. */
  place(globalRecordId: number | string): number;
  callPapyrusFunction(
    callType: "method" | "global",
    className: string,
    functionName: string,
    self: unknown,
    args: unknown[],
  ): unknown;
  lookupEspmRecordById(formId: number): unknown;
  getEspmLoadOrder(): string[];
  /** Requires a numeric mod index. Calling it with no argument throws. */
  getAllForms(modIndex: number): number[];
  getDescFromId(formId: number): string;
  getIdFromDesc(desc: string): number;
  /** Takes a desc string such as "1a26f:Skyrim.esm" plus a position array, not a form id. */
  getNeighborsByPosition(cellOrWorldDesc: string, pos: number[]): number[];
  /** Only works on indexed properties. Otherwise it logs and returns an empty array. */
  findFormsByPropertyValue(propertyName: string, value: unknown): number[];
  getUserByActor(formId: number): number;
  getActorName(formId: number): string;
  sendCustomPacket(userId: number, jsonString: string): void;

  [handler: string]: unknown;
}

declare const mp: MpApi;

export function getMp(): MpApi {
  return mp;
}
