// Deterministic serialisation, shared by anything that seals a record.
//
// It lives at the top of server/ rather than inside either feature because both the contract
// engine and the ledger seal with it, and a feature that reaches sideways into another
// feature for a primitive cannot be lifted out on its own.

// Canonical serialisation, so a document hashes to the same value every time.
//
// JSON.stringify preserves insertion order, which means two structurally identical
// documents built by different code paths serialise differently and therefore seal
// differently. A seal that depends on key order is not a seal, it is a coin flip. Every
// hash in the ledger goes through canonicalize first.

/** Values a ledger document is allowed to contain. Deliberately narrow. */
export type Canonical = string | number | boolean | null | Canonical[] | { [key: string]: Canonical };

/**
 * Deterministic JSON: object keys sorted, no incidental whitespace.
 *
 * Refuses anything that cannot survive a database round trip. undefined, functions and
 * symbols vanish silently under JSON.stringify, which would let a field be dropped between
 * sealing and verifying and produce a mismatch nobody can explain. Fail at the boundary
 * instead.
 */
export function canonicalize(value: unknown, path = "$"): string {
  if (value === null) return "null";

  const type = typeof value;

  if (type === "string") return JSON.stringify(value);

  if (type === "number") {
    if (!Number.isFinite(value as number)) {
      throw new Error(`${path} is ${String(value)}, which JSON cannot represent`);
    }
    // Negative zero stringifies as "0" but compares unequal to 0 under Object.is, so
    // normalise it rather than letting it produce two seals for one value.
    return JSON.stringify(Object.is(value, -0) ? 0 : value);
  }

  if (type === "boolean") return value === true ? "true" : "false";

  if (Array.isArray(value)) {
    return "[" + value.map((item, i) => canonicalize(item, `${path}[${i}]`)).join(",") + "]";
  }

  if (type === "object") {
    const record = value as Record<string, unknown>;
    const keys = Object.keys(record).sort();
    const parts = keys.map((key) => {
      const child = record[key];
      if (child === undefined) {
        throw new Error(`${path}.${key} is undefined, which would silently disappear from the seal`);
      }
      return JSON.stringify(key) + ":" + canonicalize(child, `${path}.${key}`);
    });
    return "{" + parts.join(",") + "}";
  }

  throw new Error(`${path} is a ${type}, which cannot be sealed`);
}
